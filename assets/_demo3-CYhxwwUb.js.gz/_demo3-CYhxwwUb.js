import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DFqQRtof.js";import"./index.vue_vue_type_script_setup_true_lang-BRjG3kWK.js";import"./index-Bnionyve.js";export{o as default};
