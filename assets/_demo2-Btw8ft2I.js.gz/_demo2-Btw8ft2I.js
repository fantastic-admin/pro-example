import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-fmiYFJdV.js";import"./index.vue_vue_type_script_setup_true_lang-GEGbrXSa.js";import"./index-BFPO48W4.js";export{o as default};
