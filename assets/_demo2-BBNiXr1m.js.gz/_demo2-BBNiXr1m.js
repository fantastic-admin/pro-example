import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-AYeI2upY.js";import"./index.vue_vue_type_script_setup_true_lang-Cg38EZsG.js";import"./index-BLSV4yIg.js";export{o as default};
