import{_ as r}from"./index.vue_vue_type_script_setup_true_lang-CnwQlPJc.js";import{d as p,f as c,g as m,h as e,j as o,i as t,a8 as l,l as d,V as i}from"./index-D4ShR5zg.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-Cduqq9iX.js";import"./index-Z-JH_SAD.js";import"./index.vue_vue_type_script_setup_true_lang-DtziN6h7.js";import"./index-BB-qkxq6.js";import"./index.vue_vue_type_script_setup_true_lang-B-jZMFQW.js";import"./index.vue_vue_type_script_setup_true_lang-DzK9jZnE.js";import"./useGraceArea-mPVArTH6.js";import"./useFormControl-BPGkY5eQ.js";import"./VisuallyHiddenInput-CMAiJUAl.js";const f=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <div class="h-vh" />
  <FaFixedActionBar>
    <div :style="\`height: \${height[0]}px;\`" />
    <FaSlider v-model="height" />
  </FaFixedActionBar>
</template>
`,h=p({__name:"index",setup(u){return(F,n)=>{const a=l,s=r;return m(),c("div",null,[e(a,{title:"固定底部操作栏"},{description:o(()=>n[0]||(n[0]=[t("div",{class:"space-y-2"},[t("p",null,"FaFixedActionBar"),t("p",null,"避免因页面过长，导致操作按钮需要滚动到页面底部才能操作")],-1)])),_:1}),e(s,{code:d(f)},{default:o(()=>[e(_)]),_:1},8,["code"])])}}});typeof i=="function"&&i(h);export{h as default};
