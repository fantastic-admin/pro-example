import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Borsv-2i.js";import"./index.vue_vue_type_script_setup_true_lang-BknbM85t.js";import"./index-Bnionyve.js";export{o as default};
