import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BSAdXoEs.js";import"./index-CkQ8ZzMl.js";import"./department-1xRcaw9s.js";export{o as default};
