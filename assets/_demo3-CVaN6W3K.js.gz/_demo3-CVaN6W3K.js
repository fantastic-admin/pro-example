import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-RQr6KRsZ.js";import"./index.vue_vue_type_script_setup_true_lang-B5ZVEnGJ.js";import"./index-Cm5PYwOf.js";export{o as default};
