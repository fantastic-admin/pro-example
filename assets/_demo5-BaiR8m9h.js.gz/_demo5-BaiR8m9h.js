import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-Dq2OHAVm.js";import"./index-BLSV4yIg.js";import"./index.vue_vue_type_script_setup_true_lang-qKXiSJOT.js";export{o as default};
