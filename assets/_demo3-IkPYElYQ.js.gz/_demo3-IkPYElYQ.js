import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CrATJIYc.js";import"./index.vue_vue_type_script_setup_true_lang-siyIZo4v.js";import"./index-DFNzsyWB.js";export{o as default};
