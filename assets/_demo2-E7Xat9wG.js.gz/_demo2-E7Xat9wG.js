import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Bypv04IZ.js";import"./index-ZQ4CAy02.js";import"./index-D4ShR5zg.js";export{o as default};
