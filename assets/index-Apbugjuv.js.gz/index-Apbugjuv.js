import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B4WK5oPN.js";import"./index-28uxndRW.js";import"./role-BozqNELA.js";export{o as default};
