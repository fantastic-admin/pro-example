import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-h7Xurfb-.js";import"./index.vue_vue_type_script_setup_true_lang-DwNki4sp.js";import"./index-Bnionyve.js";export{o as default};
