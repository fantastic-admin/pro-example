import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C5Sw2HT6.js";import"./index.vue_vue_type_script_setup_true_lang-CnrQBZV9.js";import"./index-CngbNVLW.js";export{o as default};
