import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BOL0srrX.js";import"./dictionary-DT-73YUi.js";import"./index-D4ACN76T.js";export{o as default};
