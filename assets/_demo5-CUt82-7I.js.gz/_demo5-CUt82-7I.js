import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BliaLyb_.js";import"./index.vue_vue_type_script_setup_true_lang-DDSAMHje.js";import"./index-De8Oh0HC.js";export{o as default};
