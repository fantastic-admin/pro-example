import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BHRyRiKj.js";import"./index-DQdGVpLy.js";import"./index.vue_vue_type_script_setup_true_lang-gy7OS-rh.js";export{o as default};
