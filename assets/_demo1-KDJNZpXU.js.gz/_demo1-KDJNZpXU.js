import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CctgkBxw.js";import"./index-B1fOV-41.js";import"./index-DODNO_Fi.js";export{o as default};
