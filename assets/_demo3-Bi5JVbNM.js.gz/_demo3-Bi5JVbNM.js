import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Dut59URN.js";import"./index.vue_vue_type_script_setup_true_lang-DS1moEe8.js";import"./index-DuOv7Qep.js";export{o as default};
