import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-B_vcct6v.js";import"./index.vue_vue_type_script_setup_true_lang-BG3F60_p.js";import"./index-DOTJNdHl.js";export{o as default};
