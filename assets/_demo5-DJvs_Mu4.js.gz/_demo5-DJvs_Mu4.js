import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BOTU2yTi.js";import"./index-CngbNVLW.js";import"./index.vue_vue_type_script_setup_true_lang-DLw2ThJ6.js";export{o as default};
