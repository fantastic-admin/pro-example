import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-CmISsmFh.js";import"./index.vue_vue_type_script_setup_true_lang-DjAoh3n3.js";import"./index-Dv6GDtcN.js";export{o as default};
