import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DGxG3uGv.js";import"./index-BLENON4v.js";import"./index-B13-Jify.js";export{o as default};
