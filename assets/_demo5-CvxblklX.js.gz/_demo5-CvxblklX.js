import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-EqXi1kcC.js";import"./index-DODNO_Fi.js";import"./index.vue_vue_type_script_setup_true_lang-Bn8j-fw1.js";export{o as default};
