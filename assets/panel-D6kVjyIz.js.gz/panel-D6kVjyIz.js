import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-DGwxv8Yt.js";import"./index-8eOOZCt1.js";import"./all.vue_vue_type_script_setup_true_lang-CuCWBC0h.js";export{o as default};
