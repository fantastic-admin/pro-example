import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BX21fMQh.js";import"./index.vue_vue_type_script_setup_true_lang-CA7JtHGm.js";import"./index-xj0hzzoN.js";export{o as default};
