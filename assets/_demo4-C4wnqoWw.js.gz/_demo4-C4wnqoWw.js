import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Car7Mza_.js";import"./index.vue_vue_type_script_setup_true_lang-C6by5y77.js";import"./index-COkggZqL.js";export{o as default};
