import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CnwQlPJc.js";import{d as c,f as i,g as s,h as e,a8 as r,j as m,l as _,V as t}from"./index-D4ShR5zg.js";import p from"./_demo1-L0Bz0L3u.js";import"./index-Z-JH_SAD.js";const d=`<template>
  <div class="flex gap-4">
    <FaInteractiveButton text="Fantastic-admin" />
    <FaInteractiveButton text="Vue.js" />
  </div>
</template>
`,f=c({__name:"index",setup(l){return(u,v)=>{const n=r,a=o;return s(),i("div",null,[e(n,{title:"交互式按钮",description:"FaInteractiveButton"}),e(a,{code:_(d)},{default:m(()=>[e(p)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
