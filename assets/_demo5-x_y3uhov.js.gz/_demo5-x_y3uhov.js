import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-DzkqV5TR.js";import"./index-H6QnEWHf.js";import"./index.vue_vue_type_script_setup_true_lang-CkzNAruQ.js";export{o as default};
