import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-CrG_Ifu2.js";import"./index-CkQ8ZzMl.js";import"./index.vue_vue_type_script_setup_true_lang-Hm2dgnIJ.js";export{o as default};
