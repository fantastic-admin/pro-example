import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bv8psy85.js";import"./index-CkXBA4BI.js";import"./menu-dXikkoqM.js";import"./role-C8rNqeIN.js";export{o as default};
