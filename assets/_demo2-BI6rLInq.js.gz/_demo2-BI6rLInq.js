import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BjpCA-eL.js";import"./index-BhKpcfQR.js";import"./index-H6KsPIiT.js";export{o as default};
