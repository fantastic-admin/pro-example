import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-_KhhLC8e.js";import"./index.vue_vue_type_script_setup_true_lang-CHMWgUly.js";import"./index-H6KsPIiT.js";export{o as default};
