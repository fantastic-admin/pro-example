import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DlBZDtx9.js";import"./index-CyfTND0F.js";import"./index-Cm5PYwOf.js";export{o as default};
