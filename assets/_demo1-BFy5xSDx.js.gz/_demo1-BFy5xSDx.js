import{A as e,S as t,Y as n}from"./vue.runtime.esm-bundler-EJiOFDNb.js";import{_t as r}from"./components-Dvnhr4Ep.js";var i=`<FaCard title="卡片标题" description="卡片描述" class="w-80">
  卡片内容
  <template #footer>
    卡片底部
  </template>
</FaCard>`,a=e({__name:`_demo1`,setup(e){return(e,a)=>{let o=r;return n(),t(o,{code:i,class:`flex-1`})}}});export{a as t};