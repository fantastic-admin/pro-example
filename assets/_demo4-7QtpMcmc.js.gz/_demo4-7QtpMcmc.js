import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang--oqOLQmm.js";import"./index.vue_vue_type_script_setup_true_lang-Dv7E8-6Y.js";import"./index-DRFMav3n.js";export{o as default};
