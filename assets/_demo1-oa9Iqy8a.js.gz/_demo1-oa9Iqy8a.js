import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BrvxmemF.js";import"./index-9f5q31jc.js";import"./index-DuOv7Qep.js";export{o as default};
