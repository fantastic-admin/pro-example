import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BNy_Ao_e.js";import"./index-Cr9jXCSR.js";import"./index-KSDvm3cB.js";export{o as default};
