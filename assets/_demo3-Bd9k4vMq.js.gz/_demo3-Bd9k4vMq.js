import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CkUO3fd5.js";import"./index.vue_vue_type_script_setup_true_lang-jrjWFRJA.js";import"./index-B13-Jify.js";export{o as default};
