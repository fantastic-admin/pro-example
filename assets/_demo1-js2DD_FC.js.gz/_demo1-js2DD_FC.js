import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CGQLdP7W.js";import"./index.vue_vue_type_script_setup_true_lang-CS0eXBzO.js";import"./index-BHkWVPDT.js";export{o as default};
