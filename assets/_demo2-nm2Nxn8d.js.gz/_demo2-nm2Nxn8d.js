import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DUXMPG2Z.js";import"./index.vue_vue_type_script_setup_true_lang-CW0fgqfj.js";import"./index-H6QnEWHf.js";export{o as default};
