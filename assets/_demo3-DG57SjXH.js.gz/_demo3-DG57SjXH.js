import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-B9ddpo3q.js";import"./index.vue_vue_type_script_setup_true_lang-BOm8dtR3.js";import"./index-COkggZqL.js";export{o as default};
