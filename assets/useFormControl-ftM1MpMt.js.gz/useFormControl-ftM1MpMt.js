import{J as r,aR as t,aS as a}from"./index-H6KsPIiT.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
