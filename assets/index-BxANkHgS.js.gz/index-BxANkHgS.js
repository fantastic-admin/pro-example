import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-EKUAK20M.js";import"./logo-A4CMGNjt.js";import"./index-BHkWVPDT.js";export{o as default};
