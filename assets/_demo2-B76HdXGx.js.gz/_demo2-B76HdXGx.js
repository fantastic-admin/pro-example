import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Duc7L8cn.js";import"./index-Dk37_K7O.js";import"./index-DcACV9AR.js";export{o as default};
