import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BNGlZAr1.js";import"./index-8eOOZCt1.js";export{m as default};
