import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CZv_p6sS.js";import"./department-BxsLl3A8.js";import"./index-BIIATpY8.js";export{o as default};
