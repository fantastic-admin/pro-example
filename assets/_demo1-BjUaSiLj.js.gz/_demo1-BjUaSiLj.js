import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BOiUyIvP.js";import"./index.vue_vue_type_script_setup_true_lang-Buo7s3r-.js";import"./index-De8Oh0HC.js";export{o as default};
