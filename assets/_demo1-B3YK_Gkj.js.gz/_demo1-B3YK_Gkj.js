import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-t5i00Nqm.js";import"./index.vue_vue_type_script_setup_true_lang-B87Hdx3o.js";import"./index-DODNO_Fi.js";export{o as default};
