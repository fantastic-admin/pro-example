import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Bpcxlep3.js";import"./index.vue_vue_type_script_setup_true_lang-B30t5DCf.js";import"./index-DuOv7Qep.js";export{o as default};
