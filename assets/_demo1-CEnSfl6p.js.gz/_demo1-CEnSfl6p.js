import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D4XvR73R.js";import"./index-CLFnJwio.js";import"./index-Bhq0NWKR.js";export{o as default};
