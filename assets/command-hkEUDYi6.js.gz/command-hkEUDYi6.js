import{_ as o}from"./command.vue_vue_type_script_setup_true_lang-DoWZ8DPb.js";import"./index.vue_vue_type_script_setup_true_lang-CU8yepBs.js";import"./index-Dk37_K7O.js";export{o as default};
