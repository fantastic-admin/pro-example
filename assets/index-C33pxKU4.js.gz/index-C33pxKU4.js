import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BU3PdXQ7.js";import"./index-Dv6GDtcN.js";import"./department-D1z9gSGV.js";export{o as default};
