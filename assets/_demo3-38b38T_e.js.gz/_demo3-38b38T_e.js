import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DFjXppVd.js";import"./index.vue_vue_type_script_setup_true_lang-D0esNN4o.js";import"./index-28uxndRW.js";export{o as default};
