import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D8F3Z1UG.js";import"./index-DgIgHwyh.js";import"./role-BTdkheW5.js";export{o as default};
