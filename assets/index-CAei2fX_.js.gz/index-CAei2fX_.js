import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C8ugMDSk.js";import"./index-Bhq0NWKR.js";import"./menu-CJWeHlAO.js";import"./role-DrlVQlsJ.js";export{o as default};
