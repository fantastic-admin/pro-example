import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DJzpJ8I8.js";import"./index-DJqLA50Q.js";import"./index-28uxndRW.js";export{o as default};
