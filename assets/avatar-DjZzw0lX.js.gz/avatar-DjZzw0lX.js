import{A as e,Nt as t,O as n,Y as r,pt as i,w as a}from"./vue.runtime.esm-bundler-31VjfBU5.js";import{F as o,bt as s}from"./components-CNfuk_zw.js";import{n as c}from"./vue-i18n.runtime-BkMmoySD.js";import{t as l}from"./_demo1-CCAMdzII.js";var u=`<template>
  <div class="flex gap-4">
    <FaAvatar src="https://fantastic-admin.hurui.me/logo.svg" />
    <FaAvatar src="" fallback="Hooray" />
    <div class="flex space-x--2 *:data-[slot=avatar]:ring-2 *:data-[slot=avatar]:ring-background">
      <FaTooltip text="Fantastic-admin">
        <FaAvatar src="https://github.com/fantastic-admin.png" class="transition hover:scale-110 hover:z-1" />
      </FaTooltip>
      <FaTooltip text="Hooray">
        <FaAvatar src="https://github.com/hooray.png" class="transition hover:scale-110 hover:z-1" />
      </FaTooltip>
      <FaTooltip text="Admin">
        <FaAvatar src="https://api.dicebear.com/9.x/bottts-neutral/svg?seed=admin" class="transition hover:scale-110 hover:z-1" />
      </FaTooltip>
    </div>
  </div>
</template>
`,d=e({__name:`index`,setup(e){let{t:d}=c();return(e,c)=>{let f=o,p=s;return r(),a(`div`,null,[n(f,{title:t(d)(`route.component.avatar`),description:`FaAvatar`},null,8,[`title`]),n(p,{code:t(u)},{default:i(()=>[n(l)]),_:1},8,[`code`])])}}});export{d as default};