import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DzyTue6k.js";import"./department-CwF2g9Cm.js";import"./index-KSDvm3cB.js";export{o as default};
