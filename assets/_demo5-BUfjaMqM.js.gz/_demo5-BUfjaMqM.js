import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C0hTcJHs.js";import"./index-xj0hzzoN.js";import"./index.vue_vue_type_script_setup_true_lang-IHaaDYed.js";export{o as default};
