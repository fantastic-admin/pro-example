import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang--FO6Ns-b.js";import"./index.vue_vue_type_script_setup_true_lang-H-eZQD4L.js";import"./index-DQdGVpLy.js";export{o as default};
