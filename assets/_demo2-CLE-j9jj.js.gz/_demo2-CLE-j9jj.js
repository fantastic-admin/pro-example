import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C_qW-13F.js";import"./index.vue_vue_type_script_setup_true_lang-B9iIMIvK.js";import"./index-28uxndRW.js";export{o as default};
