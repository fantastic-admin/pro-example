import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-D6BpgeZ9.js";import"./index-BIIATpY8.js";import"./all.vue_vue_type_script_setup_true_lang-Bic9dtFL.js";export{o as default};
