import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D7rwCh3Z.js";import"./dictionary-B0ruroFf.js";import"./index-Bbf2k3Iz.js";export{o as default};
