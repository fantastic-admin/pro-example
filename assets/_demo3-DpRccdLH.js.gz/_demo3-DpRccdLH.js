import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DhXmSAnE.js";import"./index.vue_vue_type_script_setup_true_lang-B3EmAFte.js";import"./index-DRFMav3n.js";export{o as default};
