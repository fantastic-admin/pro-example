import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BrlDtaa8.js";import"./index.vue_vue_type_script_setup_true_lang-BqIYCRlM.js";import"./index-De8Oh0HC.js";export{o as default};
