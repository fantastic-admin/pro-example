import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-B80fkicu.js";import"./index-DN5wyfYh.js";import"./index-Bhq0NWKR.js";export{o as default};
