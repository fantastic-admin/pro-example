import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Dxj0PKgl.js";import"./index-bUXOKEJU.js";import"./index-Bhq0NWKR.js";export{o as default};
