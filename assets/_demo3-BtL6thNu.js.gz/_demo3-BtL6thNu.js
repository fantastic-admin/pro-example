import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DT_lHoFi.js";import"./index.vue_vue_type_script_setup_true_lang-DjAoh3n3.js";import"./index-Dv6GDtcN.js";export{o as default};
