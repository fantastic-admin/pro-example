import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-CQM4P6Jf.js";import"./index-Dv6GDtcN.js";import"./index.vue_vue_type_script_setup_true_lang-Cs6JfAwn.js";export{o as default};
