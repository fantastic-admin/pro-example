import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BzOdbvNi.js";import"./index.vue_vue_type_script_setup_true_lang-CLYFwZ9h.js";import"./index-553qAUTx.js";export{o as default};
