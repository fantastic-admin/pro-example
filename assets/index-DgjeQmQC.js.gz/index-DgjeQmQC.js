import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DZgZ70Zs.js";import"./dictionary-CTmGK4ee.js";import"./index-DODNO_Fi.js";export{o as default};
