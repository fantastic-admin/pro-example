import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-id8Hne3c.js";import"./index-CsSDrlYc.js";export{m as default};
