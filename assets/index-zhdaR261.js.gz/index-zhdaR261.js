import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-BhnjE5ZP.js";import{d as r,f as c,g as s,h as e,a8 as m,j as i,l as p,V as t}from"./index-KSDvm3cB.js";import _ from"./_demo1-BwY4hrzb.js";import"./index-Cr9jXCSR.js";import"./index.vue_vue_type_script_setup_true_lang-C9W7u1m_.js";const d=`<template>
  <FaCard title="卡片标题" description="卡片描述" class="w-80">
    卡片内容
    <template #footer>
      卡片底部
    </template>
  </FaCard>
</template>
`,l=r({__name:"index",setup(f){return(u,C)=>{const a=m,o=n;return s(),c("div",null,[e(a,{title:"卡片",description:"FaCard"}),e(o,{code:p(d)},{default:i(()=>[e(_)]),_:1},8,["code"])])}}});typeof t=="function"&&t(l);export{l as default};
