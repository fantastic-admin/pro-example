import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-C_gLZobL.js";import"./index.vue_vue_type_script_setup_true_lang-DaEXSFQU.js";import"./index-Bnionyve.js";export{o as default};
