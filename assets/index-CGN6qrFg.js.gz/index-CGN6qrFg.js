import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BOtygoN5.js";import"./dictionary-COFfpWcZ.js";import"./index-De8Oh0HC.js";export{o as default};
