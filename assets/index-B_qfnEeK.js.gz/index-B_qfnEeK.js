import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dc2rQcCM.js";import"./index-H6KsPIiT.js";import"./department-jX26x5Mb.js";export{o as default};
