import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D4fqi5BA.js";import"./department-D_Te8mTM.js";import"./index-BFPO48W4.js";export{o as default};
