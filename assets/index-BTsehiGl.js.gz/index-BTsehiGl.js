import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bcq0sAhH.js";import"./index-Dk37_K7O.js";import"./role-BXcHYFxW.js";export{o as default};
