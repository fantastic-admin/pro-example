import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-g8w5HU-G.js";import{d as o,e as r,f as c,g as i,a7 as d,i as s,k as l,U as t}from"./index-CkQ8ZzMl.js";import p from"./_demo1-DyKOFR-C.js";import"./index-CAaXm9bO.js";import"./index.vue_vue_type_script_setup_true_lang-oLl-7b2p.js";import"./index.vue_vue_type_script_setup_true_lang-Bifenxpn.js";import"./useGraceArea-BWEDcFHC.js";const m=`<template>
  <div class="flex-center gap-4">
    <FaDigitalCard title="总收入" icon="i-carbon:currency-yen" digital="￥45,231.89" description="较上周上升19%" trend="up" />
    <FaDigitalCard title="订阅数" icon="i-mynaui:users" digital="+50" description="较上周下降3%" trend="down" />
    <FaDigitalCard title="销售额" icon="i-bytesize:creditcard" digital="+12,234" description="较上周上升55%" trend="stable" />
    <FaDigitalCard title="活跃用户" title-tips="仅统计近一小时的活跃用户数量" icon="i-carbon:activity" digital="+573" description="较近一小时上升10%" />
  </div>
</template>
`,_=o({__name:"index",setup(f){return(g,u)=>{const e=d,a=n;return c(),r("div",null,[i(e,{title:"数字卡片",description:"DigitalCard"}),i(a,{code:l(m)},{default:s(()=>[i(p)]),_:1},8,["code"])])}}});typeof t=="function"&&t(_);export{_ as default};
