import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Cf0D5tQW.js";import"./index.vue_vue_type_script_setup_true_lang-CDayztTI.js";import"./index-DFNzsyWB.js";export{o as default};
