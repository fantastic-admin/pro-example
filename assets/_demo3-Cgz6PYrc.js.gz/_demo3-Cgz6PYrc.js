import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BTX82pNo.js";import"./index.vue_vue_type_script_setup_true_lang-CvnRx29j.js";import"./index-BHkWVPDT.js";export{o as default};
