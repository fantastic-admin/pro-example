import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CRGH9s9M.js";import"./index-CphCexG_.js";import"./department-DbRTrigj.js";export{o as default};
