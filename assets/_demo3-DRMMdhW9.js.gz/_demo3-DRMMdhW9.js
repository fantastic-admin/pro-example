import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-wh4W9mnI.js";import"./index.vue_vue_type_script_setup_true_lang-Bt-s_oEO.js";import"./index-xj0hzzoN.js";export{o as default};
