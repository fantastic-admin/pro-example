import{x as r,D as t,E as u}from"./index-H6QnEWHf.js";function s(o){return r(()=>{var e;return t(o)?!!((e=u(o))!=null&&e.closest("form")):!0})}export{s as u};
