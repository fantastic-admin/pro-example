import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BpC6_TgX.js";import"./dictionary-DM8qE8sE.js";import"./index-xcJMzuCA.js";export{o as default};
