import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D9VnBQ_5.js";import"./index-DMc4HI8f.js";import"./role-pyM5kMOL.js";export{o as default};
