import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BtKF-aJX.js";import"./index-BIF9sd5X.js";import"./index-De8Oh0HC.js";export{o as default};
