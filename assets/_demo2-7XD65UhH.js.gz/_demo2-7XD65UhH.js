import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BUeD0Fk6.js";import"./index.vue_vue_type_script_setup_true_lang-DkM5o9N3.js";import"./index-Cm5PYwOf.js";export{o as default};
