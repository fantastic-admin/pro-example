import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-CCPMgXZI.js";import"./index-DQdGVpLy.js";import"./all.vue_vue_type_script_setup_true_lang-DhZUnGfN.js";export{o as default};
