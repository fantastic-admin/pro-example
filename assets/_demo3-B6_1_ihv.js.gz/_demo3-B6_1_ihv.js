import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-B5scIIjO.js";import"./index.vue_vue_type_script_setup_true_lang-BqY19XaB.js";import"./index-B13-Jify.js";export{o as default};
