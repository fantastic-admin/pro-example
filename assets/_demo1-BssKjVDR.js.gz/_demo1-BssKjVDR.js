import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-B37Jg8Dc.js";import"./index.vue_vue_type_script_setup_true_lang-DK3yGJfW.js";import"./index-H6QnEWHf.js";export{o as default};
