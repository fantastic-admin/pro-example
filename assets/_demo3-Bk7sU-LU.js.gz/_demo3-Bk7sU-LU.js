import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-TXCU-7Ex.js";import"./index.vue_vue_type_script_setup_true_lang-Amt8a70p.js";import"./index-De8Oh0HC.js";export{o as default};
