import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DMYw4xES.js";import"./index-Dv6GDtcN.js";import"./menu-BpDLcwjc.js";import"./role-DKInVtRR.js";export{o as default};
