import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CZMcsdxk.js";import"./index-BYSPG57E.js";import"./index-KSDvm3cB.js";export{o as default};
