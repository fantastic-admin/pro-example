import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CnHdr7DO.js";import"./index.vue_vue_type_script_setup_true_lang-D4gosICD.js";import"./index-DFNzsyWB.js";export{o as default};
