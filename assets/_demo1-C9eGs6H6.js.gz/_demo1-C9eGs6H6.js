import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BxqGOT5L.js";import"./index-C-eoLqHa.js";import"./index-CngbNVLW.js";export{o as default};
