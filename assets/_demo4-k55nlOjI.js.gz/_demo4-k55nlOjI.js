import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Bwmd9KE9.js";import"./index.vue_vue_type_script_setup_true_lang-DRIbjJEq.js";import"./index-DFNzsyWB.js";export{o as default};
