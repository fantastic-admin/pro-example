import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-IDa1zveg.js";import"./index-DODNO_Fi.js";export{m as default};
