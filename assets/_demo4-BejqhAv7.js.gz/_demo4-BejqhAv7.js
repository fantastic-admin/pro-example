import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-YC03q7GG.js";import"./index.vue_vue_type_script_setup_true_lang-Dls23fAH.js";import"./index-CngbNVLW.js";export{o as default};
