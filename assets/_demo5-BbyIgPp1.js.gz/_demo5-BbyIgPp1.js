import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-DRP1bnZ-.js";import"./index.vue_vue_type_script_setup_true_lang-DaxKbZTJ.js";import"./index-DQdGVpLy.js";export{o as default};
