import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Ck-71tN9.js";import"./index.vue_vue_type_script_setup_true_lang-BkjBPcWI.js";import"./index-DODNO_Fi.js";export{o as default};
