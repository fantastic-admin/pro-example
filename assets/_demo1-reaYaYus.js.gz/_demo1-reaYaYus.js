import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DWeNvs7a.js";import"./index-BxUiiA8L.js";import"./index-Bhq0NWKR.js";export{o as default};
