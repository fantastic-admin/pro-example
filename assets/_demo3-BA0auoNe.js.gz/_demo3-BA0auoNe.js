import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BqNN2NWp.js";import"./index.vue_vue_type_script_setup_true_lang-CJGonHve.js";import"./index-H6QnEWHf.js";export{o as default};
