import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-D0Szghxo.js";import{d as r,f as c,g as m,h as n,a8 as s,j as l,l as i,V as e}from"./index-CkXBA4BI.js";import p from"./_demo1-BPZjJmoP.js";import"./index-DwqvzQUS.js";const _=`<template>
  <FaDropdown
    :items="[
      [
        { label: '菜单1-1' },
        { label: '菜单1-2', disabled: true },
        { label: '菜单1-3' },
      ],
      [
        { label: '菜单2' },
      ],
    ]"
  >
    <FaButton>
      下拉菜单
      <FaIcon name="i-ep:caret-bottom" />
    </FaButton>
  </FaDropdown>
</template>
`,d=r({__name:"index",setup(f){return(u,F)=>{const o=s,t=a;return m(),c("div",null,[n(o,{title:"下拉菜单",description:"FaDropdown"}),n(t,{code:i(_)},{default:l(()=>[n(p)]),_:1},8,["code"])])}}});typeof e=="function"&&e(d);export{d as default};
