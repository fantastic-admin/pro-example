import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BLx3jdoY.js";import"./dictionary-CJgHEJR2.js";import"./index-Dv6GDtcN.js";export{o as default};
