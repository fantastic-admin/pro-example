import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-jBYWZT1M.js";import"./index.vue_vue_type_script_setup_true_lang-fnem0Zj7.js";import"./index-Bhq0NWKR.js";export{o as default};
