import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-oqOVxXs9.js";import"./index.vue_vue_type_script_setup_true_lang-Bmbwt0bm.js";import"./index-DOTJNdHl.js";export{o as default};
