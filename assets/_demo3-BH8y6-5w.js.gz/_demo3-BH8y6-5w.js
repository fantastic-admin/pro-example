import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-jyv-h_bK.js";import"./index.vue_vue_type_script_setup_true_lang-B_GuISb1.js";import"./index-Dv6GDtcN.js";export{o as default};
