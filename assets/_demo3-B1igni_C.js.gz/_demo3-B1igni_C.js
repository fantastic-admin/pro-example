import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DhpcXW-2.js";import"./index.vue_vue_type_script_setup_true_lang-CNfKg_6C.js";import"./index-Dv6GDtcN.js";export{o as default};
