import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BpJRVRuf.js";import"./index.vue_vue_type_script_setup_true_lang-DNaogh5D.js";import"./index-DODNO_Fi.js";export{o as default};
