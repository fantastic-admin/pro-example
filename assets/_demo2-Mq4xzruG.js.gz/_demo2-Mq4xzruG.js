import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CuoTWPs7.js";import"./index-C01HMVpC.js";import"./index-DQdGVpLy.js";export{o as default};
