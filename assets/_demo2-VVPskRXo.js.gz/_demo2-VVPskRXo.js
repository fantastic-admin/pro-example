import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BW_gmGX-.js";import"./index-DUEj3OrR.js";import"./index-COkggZqL.js";export{o as default};
