import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CmX2fYCt.js";import"./index.vue_vue_type_script_setup_true_lang-DWnVJ-Eg.js";import"./index-Cm5PYwOf.js";export{o as default};
