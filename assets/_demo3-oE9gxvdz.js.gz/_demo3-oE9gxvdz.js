import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-C1QKf4je.js";import"./index.vue_vue_type_script_setup_true_lang-8ZGaWADI.js";import"./index-28uxndRW.js";export{o as default};
