import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BSXwOnZr.js";import"./index-DkeYN8al.js";import"./index-Dv6GDtcN.js";export{o as default};
