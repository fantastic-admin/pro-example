import{A as e,Nt as t,O as n,Y as r,pt as i,w as a}from"./vue.runtime.esm-bundler-EJiOFDNb.js";import{P as o,vt as s}from"./components-Dvnhr4Ep.js";import{n as c}from"./vue-i18n.runtime-pGyDsL5y.js";import{t as l}from"./_demo1-oVLaN1hG.js";import{t as u}from"./_demo2-HXRrQYJJ.js";var d=`<template>
  <FaSpotlightCard>
    <div class="p-6 rounded flex flex-col gap-2 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        Hover me
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,f=`<template>
  <FaSpotlightCard :gradient-size="100" gradient-color="red" :gradient-opacity="1">
    <div class="p-6 rounded flex flex-col gap-2 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        Hover me
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,p=e({__name:`index`,setup(e){let{t:p}=c();return(e,c)=>{let m=o,h=s;return r(),a(`div`,null,[n(m,{title:t(p)(`route.component.spotlightCard`),description:`FaSpotlightCard`},null,8,[`title`]),n(h,{code:t(d)},{default:i(()=>[n(l)]),_:1},8,[`code`]),n(h,{title:`尺寸 / 颜色 / 透明底`,code:t(f)},{default:i(()=>[n(u)]),_:1},8,[`code`])])}}});export{p as default};