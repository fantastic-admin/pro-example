import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-DD1_fgBZ.js";import"./index.vue_vue_type_script_setup_true_lang-DkM5o9N3.js";import"./index-Cm5PYwOf.js";export{o as default};
