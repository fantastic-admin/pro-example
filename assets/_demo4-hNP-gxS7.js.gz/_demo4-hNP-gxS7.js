import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BUTriY2b.js";import"./index.vue_vue_type_script_setup_true_lang-DaxKbZTJ.js";import"./index-DQdGVpLy.js";export{o as default};
