import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-CZ4Fi-Fa.js";import"./index-8eOOZCt1.js";import"./index.vue_vue_type_script_setup_true_lang-CGl6FzL8.js";export{o as default};
