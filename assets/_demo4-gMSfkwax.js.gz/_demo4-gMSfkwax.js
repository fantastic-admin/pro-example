import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Dq_VmuhT.js";import"./index.vue_vue_type_script_setup_true_lang-BrLQxncz.js";import"./index-8eOOZCt1.js";export{o as default};
