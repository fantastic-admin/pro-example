import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BSglYT0X.js";import"./index.vue_vue_type_script_setup_true_lang-BaoSFxjf.js";import"./index-KSDvm3cB.js";export{o as default};
