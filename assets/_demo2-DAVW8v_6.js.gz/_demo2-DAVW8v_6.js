import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Db1tjx9k.js";import"./index-BD_OYikY.js";import"./index-CphCexG_.js";export{o as default};
