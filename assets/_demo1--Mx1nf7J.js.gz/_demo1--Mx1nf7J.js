import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BI70aepE.js";import"./index-NjXLq1Fr.js";import"./index-DOTJNdHl.js";export{o as default};
