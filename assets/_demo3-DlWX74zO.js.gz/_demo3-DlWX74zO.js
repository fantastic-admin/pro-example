import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DoAqcdlA.js";import"./index.vue_vue_type_script_setup_true_lang-SqDhYYOY.js";import"./index-CphCexG_.js";export{o as default};
