import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DALvZSCa.js";import"./index-CRGv7gQG.js";import"./index-DQdGVpLy.js";export{o as default};
