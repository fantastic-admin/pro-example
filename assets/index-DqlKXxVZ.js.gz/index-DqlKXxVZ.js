import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-D0Szghxo.js";import{d as s,f as r,g as c,h as a,a8 as i,j as m,l as p,V as e}from"./index-CkXBA4BI.js";import f from"./_demo1-C06xSra9.js";import"./index-DwqvzQUS.js";import"./index.vue_vue_type_script_setup_true_lang-B86EACCG.js";const l=`<template>
  <div class="flex gap-4">
    <FaAvatar src="https://fantastic-admin.hurui.me/logo.svg" />
    <FaAvatar src="https://fantastic-admin.hurui.me/logo.svg" shape="square" />
    <FaAvatar src="" fallback="Hooray" />
  </div>
</template>
`,_=s({__name:"index",setup(d){return(u,v)=>{const t=i,o=n;return c(),r("div",null,[a(t,{title:"头像",description:"FaAvatar"}),a(o,{code:p(l)},{default:m(()=>[a(f)]),_:1},8,["code"])])}}});typeof e=="function"&&e(_);export{_ as default};
