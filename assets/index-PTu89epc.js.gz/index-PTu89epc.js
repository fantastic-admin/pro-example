import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DawGJXgZ.js";import"./index-Bnionyve.js";import"./role-DVrXwFu0.js";export{o as default};
