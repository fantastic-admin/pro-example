import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-oT1A7ck4.js";import"./index.vue_vue_type_script_setup_true_lang-Cnfua8Xc.js";import"./index-H6KsPIiT.js";export{o as default};
