import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BdeFhODw.js";import"./index-CEcMOYC7.js";import"./index-xj0hzzoN.js";export{o as default};
