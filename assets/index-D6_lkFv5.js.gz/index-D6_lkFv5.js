import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BWnYjA0X.js";import"./department-C1cqOPOA.js";import"./index-DuOv7Qep.js";export{o as default};
