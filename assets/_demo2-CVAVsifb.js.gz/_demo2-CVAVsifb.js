import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DTuRu_8M.js";import"./index.vue_vue_type_script_setup_true_lang-BGM6I5J3.js";import"./index-B13-Jify.js";export{o as default};
