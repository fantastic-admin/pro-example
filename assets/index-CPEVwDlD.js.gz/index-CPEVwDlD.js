import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-EgipfE_5.js";import{d as i,e as c,f as m,g as e,a7 as r,i as p,k as s,U as o}from"./index-De8Oh0HC.js";import _ from"./_demo1-I5akE8NW.js";import"./index-CRjmYGFS.js";import"./index.vue_vue_type_script_setup_true_lang-BKeNCK96.js";import"./useGraceArea-Ck6zYDPK.js";const l=`<template>
  <FaTooltip text="注意噢！">
    <FaIcon name="i-ri:question-line" />
  </FaTooltip>
</template>
`,f=i({__name:"index",setup(d){return(u,F)=>{const t=r,n=a;return m(),c("div",null,[e(t,{title:"文字提示",description:"FaTooltip"}),e(n,{code:s(l)},{default:p(()=>[e(_)]),_:1},8,["code"])])}}});typeof o=="function"&&o(f);export{f as default};
