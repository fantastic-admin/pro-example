import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BUdXuyXP.js";import"./index-DeBGuEWd.js";import"./index-xj0hzzoN.js";export{o as default};
