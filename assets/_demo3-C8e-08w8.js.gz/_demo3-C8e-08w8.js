import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BNCes-W2.js";import"./index.vue_vue_type_script_setup_true_lang-BWdxqDq8.js";import"./index-D4ShR5zg.js";export{o as default};
