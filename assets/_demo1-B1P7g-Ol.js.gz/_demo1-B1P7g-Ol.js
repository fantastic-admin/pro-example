import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-n4VN0_0l.js";import"./index-D_V_eJgL.js";import"./index-Bnionyve.js";export{o as default};
