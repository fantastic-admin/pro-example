import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BVErKwgB.js";import"./index.vue_vue_type_script_setup_true_lang-BTCmFe3p.js";import"./index-B13-Jify.js";export{o as default};
