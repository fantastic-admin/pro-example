import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-dZkwOBQR.js";import"./index-BFPO48W4.js";import"./role-CvcwOSe2.js";export{o as default};
