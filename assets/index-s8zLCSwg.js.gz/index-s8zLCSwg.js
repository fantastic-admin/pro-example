import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-EgipfE_5.js";import{d as r,e as s,f as m,g as e,a7 as c,i,k as p,U as o}from"./index-De8Oh0HC.js";import _ from"./_demo1-ClXv4Cqo.js";import"./index-CRjmYGFS.js";import"./index.vue_vue_type_script_setup_true_lang-BtvjbulO.js";import"./nullish-CHIgUVhi.js";const f=`<template>
  <FaProgress :model-value="33" />
</template>
`,d=r({__name:"index",setup(l){return(u,g)=>{const t=c,a=n;return m(),s("div",null,[e(t,{title:"进度条",description:"FaProgress"}),e(a,{code:p(f)},{default:i(()=>[e(_)]),_:1},8,["code"])])}}});typeof o=="function"&&o(d);export{d as default};
