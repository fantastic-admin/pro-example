import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-iFov3akP.js";import{d as r,f as s,g as i,h as e,a8 as c,j as d,l as m,V as n}from"./index-Dv6GDtcN.js";import l from"./_demo1-DpE1vm9c.js";import"./index-DNIjrW4p.js";import"./index.vue_vue_type_script_setup_true_lang-DGo_j6Pt.js";const p=`<template>
  <FaContextMenu
    :items="[
      [
        { label: '菜单1-1' },
        { label: '菜单1-2', disabled: true },
        { label: '菜单1-3', icon: 'i-ep:edit' },
      ],
      [
        { label: '菜单2' },
      ],
    ]"
  >
    <div class="h-[150px] w-[300px] flex items-center justify-center border rounded-md border-dashed text-sm">
      在这右键
    </div>
  </FaContextMenu>
</template>
`,_=r({__name:"index",setup(f){return(u,x)=>{const t=c,o=a;return i(),s("div",null,[e(t,{title:"右键菜单",description:"FaContextMenu"}),e(o,{code:m(p)},{default:d(()=>[e(l)]),_:1},8,["code"])])}}});typeof n=="function"&&n(_);export{_ as default};
