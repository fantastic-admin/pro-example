import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DQTkYpA0.js";import"./index-CphCexG_.js";import"./index-CXdqj4-8.js";export{o as default};
