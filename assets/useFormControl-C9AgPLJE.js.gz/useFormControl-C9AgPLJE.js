import{M as r,a$ as t,b0 as u}from"./index-B13-Jify.js";function n(o){return r(()=>{var e;return t(o)?!!((e=u(o))!=null&&e.closest("form")):!0})}export{n as u};
