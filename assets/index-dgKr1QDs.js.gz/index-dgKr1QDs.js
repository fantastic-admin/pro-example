import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C-sMNtfE.js";import"./index-Cm5PYwOf.js";import"./menu-DQUIlntu.js";import"./role-D2Y2SsC0.js";export{o as default};
