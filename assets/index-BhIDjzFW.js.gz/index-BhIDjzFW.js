import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C3pjQ_Y6.js";import{d as s,e as i,f as r,g as e,a7 as c,i as d,k as m,U as t}from"./index-BLSV4yIg.js";import l from"./_demo1-C8StdL2H.js";import"./index-DU7ESt7E.js";const p=`<template>
  <div class="h-100 flex items-center justify-center">
    <div class="mx-auto text-4xl text-neutral-600 font-semibold dark:text-neutral-400">
      Vue.js 是一款
      <FaFlipWords
        :words="['渐进式', '易上手的', '高性能', '多功能']"
        :duration="3000"
        class="text-4xl !text-primary"
      />
      JavaScript 框架
      <div class="mt-4">
        用于构建现代 Web 应用
      </div>
    </div>
  </div>
</template>
`,_=s({__name:"index",setup(f){return(u,x)=>{const n=c,a=o;return r(),i("div",null,[e(n,{title:"翻转文字",description:"FaFlipWords"}),e(a,{code:m(p)},{default:d(()=>[e(l)]),_:1},8,["code"])])}}});typeof t=="function"&&t(_);export{_ as default};
