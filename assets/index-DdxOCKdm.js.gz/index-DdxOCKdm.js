import{_ as r}from"./index.vue_vue_type_script_setup_true_lang-g8w5HU-G.js";import{d as p,e as c,f as m,g as e,i as o,h as t,a7 as d,k as l,U as i}from"./index-CkQ8ZzMl.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-C0DJtEWl.js";import"./index-CAaXm9bO.js";import"./index.vue_vue_type_script_setup_true_lang-DLGc_R1T.js";import"./index-0um1i_51.js";import"./index.vue_vue_type_script_setup_true_lang-BAmqFViL.js";import"./index.vue_vue_type_script_setup_true_lang-Bifenxpn.js";import"./useGraceArea-BWEDcFHC.js";import"./useFormControl-DP40Ef6l.js";import"./VisuallyHiddenInput-BvUOAc6v.js";const f=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <div class="h-vh" />
  <FaFixedActionBar>
    <div :style="\`height: \${height[0]}px;\`" />
    <FaSlider v-model="height" />
  </FaFixedActionBar>
</template>
`,h=p({__name:"index",setup(u){return(F,n)=>{const a=d,s=r;return m(),c("div",null,[e(a,{title:"固定底部操作栏"},{description:o(()=>n[0]||(n[0]=[t("div",{class:"space-y-2"},[t("p",null,"FaFixedActionBar"),t("p",null,"避免因页面过长，导致操作按钮需要滚动到页面底部才能操作")],-1)])),_:1}),e(s,{code:l(f)},{default:o(()=>[e(_)]),_:1},8,["code"])])}}});typeof i=="function"&&i(h);export{h as default};
