import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BkK32cgy.js";import"./index.vue_vue_type_script_setup_true_lang-BlPjrugw.js";import"./index-H6KsPIiT.js";export{o as default};
