import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-D07sZXBe.js";import"./index.vue_vue_type_script_setup_true_lang-DjAoh3n3.js";import"./index-Dv6GDtcN.js";export{o as default};
