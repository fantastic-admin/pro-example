import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-RURSfMja.js";import"./index-D6ZFILMt.js";import"./index-BHkWVPDT.js";export{o as default};
