import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-B8fjhY3u.js";import"./index-Bhq0NWKR.js";import"./index.vue_vue_type_script_setup_true_lang-BaEq4DRg.js";export{o as default};
