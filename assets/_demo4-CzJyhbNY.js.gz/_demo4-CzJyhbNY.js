import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-C_l_lar3.js";import"./index.vue_vue_type_script_setup_true_lang-BgoLOkBf.js";import"./index-BLSV4yIg.js";export{o as default};
