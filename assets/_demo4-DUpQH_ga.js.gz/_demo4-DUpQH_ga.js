import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BFeolduw.js";import"./index.vue_vue_type_script_setup_true_lang-BbY-5ph-.js";import"./index-DQdGVpLy.js";export{o as default};
