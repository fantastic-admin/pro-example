import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CiA77rN-.js";import{d as s,f as c,g as r,h as e,a8 as p,j as _,l as i,V as t}from"./index-xj0hzzoN.js";import{_ as m}from"./_demo1.vue_vue_type_script_setup_true_lang-BUMN7zBd.js";import"./index-BIrqzr6m.js";const l=`<script setup lang="ts">
const value = ref('')
<\/script>

<template>
  <FaInput v-model="value" placeholder="请输入内容" />
</template>
`,f=s({__name:"index",setup(d){return(u,v)=>{const n=p,a=o;return r(),c("div",null,[e(n,{title:"输入框",description:"FaInput"}),e(a,{code:i(l)},{default:_(()=>[e(m)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
