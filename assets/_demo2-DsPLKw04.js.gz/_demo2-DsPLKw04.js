import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-0wT8XTQy.js";import"./index.vue_vue_type_script_setup_true_lang-B_LZ-bto.js";import"./index-D4ShR5zg.js";export{o as default};
