import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-iG4f0EwE.js";import"./index-Uj1YccNM.js";import"./index-BFPO48W4.js";export{o as default};
