import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Dhy9CEq6.js";import"./index-ClELmDgR.js";import"./index-H6QnEWHf.js";export{o as default};
