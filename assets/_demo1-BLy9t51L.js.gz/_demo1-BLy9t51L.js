import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CjcF23Ef.js";import"./index-C2sVwYqs.js";import"./index-Bnionyve.js";export{o as default};
