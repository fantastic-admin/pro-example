import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BZtL3HAe.js";import"./index.vue_vue_type_script_setup_true_lang-BdpatcUf.js";import"./index-B13-Jify.js";export{o as default};
