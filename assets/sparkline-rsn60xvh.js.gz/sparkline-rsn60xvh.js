import{A as e,Nt as t,O as n,Y as r,pt as i,w as a}from"./vue.runtime.esm-bundler-EJiOFDNb.js";import{P as o,vt as s}from"./components-Dvnhr4Ep.js";import{n as c}from"./vue-i18n.runtime-pGyDsL5y.js";import{t as l}from"./_demo1-D2XZy60C2.js";var u=`<script setup lang="ts">
const value1 = ref([1, 5, 2, 4, 8, 3, 7])
const value2 = ref([
  { tooltip: '1', value: 1 },
  { tooltip: '3', value: 3 },
  { tooltip: '5', value: 5 },
  { tooltip: '8', value: 8 },
  { tooltip: '4', value: 4 },
  { tooltip: '6', value: 6 },
  { tooltip: '9', value: 9 },
])
<\/script>

<template>
  <FaSparkline :value="value1" />
  <FaSparkline :value="value1" stroke-color="#409eff" fill-color="#b3d8ff" />
  <FaSparkline :value="value2" tooltip />
  <FaSparkline :value="value2" tooltip stroke-color="#409eff" fill-color="#b3d8ff" cursor-color="#e6a23c" spot-color="#909399" />
</template>
`,d=e({__name:`index`,setup(e){let{t:d}=c();return(e,c)=>{let f=o,p=s;return r(),a(`div`,null,[n(f,{title:t(d)(`route.component.sparkline`),description:`FaSparkline`},null,8,[`title`]),n(p,{code:t(u)},{default:i(()=>[n(l)]),_:1},8,[`code`])])}}});export{d as default};