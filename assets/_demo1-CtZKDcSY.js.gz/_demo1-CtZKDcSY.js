import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D_YGcwLq.js";import"./index-BIrqzr6m.js";import"./index-xj0hzzoN.js";export{o as default};
