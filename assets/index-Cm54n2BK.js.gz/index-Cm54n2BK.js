import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D6sa1gR9.js";import"./index-DFNzsyWB.js";import"./role-DNPNSmyM.js";export{o as default};
