import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Cwi-owit.js";import"./index.vue_vue_type_script_setup_true_lang-DaD4wXgX.js";import"./index-CphCexG_.js";export{o as default};
