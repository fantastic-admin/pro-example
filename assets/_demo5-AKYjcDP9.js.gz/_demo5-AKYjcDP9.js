import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-De0nwOd8.js";import"./index-D4ShR5zg.js";import"./index.vue_vue_type_script_setup_true_lang-CbS-YbH5.js";export{o as default};
