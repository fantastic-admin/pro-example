import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CzmHoYB2.js";import"./index-B13-Jify.js";import"./menu-BJFArQNV.js";import"./role-C_txy_eJ.js";export{o as default};
