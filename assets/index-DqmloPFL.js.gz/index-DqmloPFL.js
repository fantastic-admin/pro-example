import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-EgipfE_5.js";import{d as c,e as i,f as s,g as e,a7 as r,i as m,k as _,U as t}from"./index-De8Oh0HC.js";import p from"./_demo1-DdUEXqOj.js";import"./index-CRjmYGFS.js";const d=`<template>
  <div class="flex gap-4">
    <FaInteractiveButton text="Fantastic-admin" />
    <FaInteractiveButton text="Vue.js" />
  </div>
</template>
`,f=c({__name:"index",setup(l){return(u,v)=>{const n=r,a=o;return s(),i("div",null,[e(n,{title:"交互式按钮",description:"FaInteractiveButton"}),e(a,{code:_(d)},{default:m(()=>[e(p)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
