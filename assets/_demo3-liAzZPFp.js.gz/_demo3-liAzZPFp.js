import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CHpi23R2.js";import"./index.vue_vue_type_script_setup_true_lang-DChKiCXQ.js";import"./index-CngbNVLW.js";export{o as default};
