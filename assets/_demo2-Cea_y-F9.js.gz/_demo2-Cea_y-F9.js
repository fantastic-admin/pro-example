import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DF0ZiIIZ.js";import"./index-m00YXFvT.js";import"./index-CngbNVLW.js";export{o as default};
