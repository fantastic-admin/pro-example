import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BJSzEi0U.js";import"./index-COkggZqL.js";import"./index.vue_vue_type_script_setup_true_lang-NjDb_GJt.js";export{o as default};
