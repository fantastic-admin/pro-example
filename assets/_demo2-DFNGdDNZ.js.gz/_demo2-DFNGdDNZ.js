import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BMQ2obEF.js";import"./index.vue_vue_type_script_setup_true_lang-DRIbjJEq.js";import"./index-DFNzsyWB.js";export{o as default};
