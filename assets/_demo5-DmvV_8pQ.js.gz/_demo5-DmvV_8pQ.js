import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BEAHKWdN.js";import"./index-De8Oh0HC.js";import"./index.vue_vue_type_script_setup_true_lang-i-5Cp3Dq.js";export{o as default};
