import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BEzUcUV_.js";import"./index-KSDvm3cB.js";import"./index.vue_vue_type_script_setup_true_lang-C0b5Gejd.js";export{o as default};
