import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CEMYFTUI.js";import"./index-CkXBA4BI.js";import"./role-C8rNqeIN.js";export{o as default};
