import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DEQq6q89.js";import"./index.vue_vue_type_script_setup_true_lang-D3rlrTQJ.js";import"./index-DODNO_Fi.js";export{o as default};
