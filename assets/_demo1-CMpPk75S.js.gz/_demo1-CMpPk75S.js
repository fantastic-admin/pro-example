import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D0DZ7Lpi.js";import"./index.vue_vue_type_script_setup_true_lang-D4gosICD.js";import"./index-DFNzsyWB.js";export{o as default};
