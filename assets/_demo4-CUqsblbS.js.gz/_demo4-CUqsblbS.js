import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-B1wLtrmM.js";import"./index.vue_vue_type_script_setup_true_lang-WTLd1ZS9.js";import"./index-KSDvm3cB.js";export{o as default};
