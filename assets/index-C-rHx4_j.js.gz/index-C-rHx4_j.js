import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DwTmXnQo.js";import"./dictionary-zM5UDmNX.js";import"./index-DOTJNdHl.js";export{o as default};
