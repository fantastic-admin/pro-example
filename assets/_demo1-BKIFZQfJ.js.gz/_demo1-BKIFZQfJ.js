import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Dk65GE5r.js";import"./index.vue_vue_type_script_setup_true_lang-BknbM85t.js";import"./index-Bnionyve.js";export{o as default};
