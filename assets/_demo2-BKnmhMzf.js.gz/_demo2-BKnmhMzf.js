import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DYnWnfWn.js";import"./index-CV07X52V.js";import"./index-Dk37_K7O.js";export{o as default};
