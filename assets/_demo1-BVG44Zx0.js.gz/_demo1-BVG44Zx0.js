import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CyYt1PU1.js";import"./index.vue_vue_type_script_setup_true_lang-CNfKg_6C.js";import"./index-Dv6GDtcN.js";export{o as default};
