import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DrbfGhv_.js";import"./index.vue_vue_type_script_setup_true_lang-RQQp9dKA.js";import"./index-DQdGVpLy.js";export{o as default};
