import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-qAy7oyEZ.js";import"./dictionary-Cb85W0Eq.js";import"./index-BLSV4yIg.js";export{o as default};
