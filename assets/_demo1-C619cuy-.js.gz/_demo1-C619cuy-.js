import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CVCMdYVC.js";import"./index.vue_vue_type_script_setup_true_lang-D6yLJuxa.js";import"./index-Bhq0NWKR.js";export{o as default};
