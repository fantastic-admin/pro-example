import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-DltvfDFZ.js";import{d as i,f as c,g as m,h as e,a8 as r,j as p,l as s,V as o}from"./index-8eOOZCt1.js";import _ from"./_demo1-DhEAJsfY.js";import"./index-P1b-IaR7.js";import"./index.vue_vue_type_script_setup_true_lang-Cad2HOzw.js";import"./useGraceArea-CrB2IdB0.js";const l=`<template>
  <FaTooltip text="注意噢！">
    <FaIcon name="i-ri:question-line" />
  </FaTooltip>
</template>
`,f=i({__name:"index",setup(d){return(u,F)=>{const t=r,n=a;return m(),c("div",null,[e(t,{title:"文字提示",description:"FaTooltip"}),e(n,{code:s(l)},{default:p(()=>[e(_)]),_:1},8,["code"])])}}});typeof o=="function"&&o(f);export{f as default};
