import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CsL1bmVZ.js";import"./index.vue_vue_type_script_setup_true_lang-CnrQBZV9.js";import"./index-CngbNVLW.js";export{o as default};
