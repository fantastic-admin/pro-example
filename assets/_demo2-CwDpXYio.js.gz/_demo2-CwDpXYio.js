import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-T1srUTsu.js";import"./index.vue_vue_type_script_setup_true_lang-CXX3tmmW.js";import"./index-BHkWVPDT.js";export{o as default};
