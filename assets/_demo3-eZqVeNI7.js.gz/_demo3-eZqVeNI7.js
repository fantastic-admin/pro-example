import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Cvl3mYUV.js";import"./index.vue_vue_type_script_setup_true_lang-7m1lLj5b.js";import"./index-CkXBA4BI.js";export{o as default};
