import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-CGTi0nYt.js";import"./index.vue_vue_type_script_setup_true_lang-BHfomNw9.js";import"./index-H6KsPIiT.js";export{o as default};
