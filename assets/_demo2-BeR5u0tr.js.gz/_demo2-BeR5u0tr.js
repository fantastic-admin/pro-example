import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-yL7keC4A.js";import"./index.vue_vue_type_script_setup_true_lang-CDwMcqST.js";import"./index-DOTJNdHl.js";export{o as default};
