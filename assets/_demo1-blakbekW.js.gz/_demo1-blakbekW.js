import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CbeNT1rk.js";import"./index-P1b-IaR7.js";import"./index-8eOOZCt1.js";export{o as default};
