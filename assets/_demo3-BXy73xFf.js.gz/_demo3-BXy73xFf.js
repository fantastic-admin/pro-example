import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BObrJlEt.js";import"./index.vue_vue_type_script_setup_true_lang-CSeu5dqm.js";import"./index-COkggZqL.js";export{o as default};
