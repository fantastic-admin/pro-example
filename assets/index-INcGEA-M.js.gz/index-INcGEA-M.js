import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-g8w5HU-G.js";import{d as t,e as c,f as r,g as a,a7 as d,i as m,k as s,U as e}from"./index-CkQ8ZzMl.js";import l from"./_demo1-B2d-XXIz.js";import"./index-CAaXm9bO.js";import"./index.vue_vue_type_script_setup_true_lang-D9M1JjI2.js";const f=`<template>
  <div class="flex gap-8">
    <FaBadge :value="true">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge :value="99">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="噢">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="9" variant="secondary">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="9" variant="destructive">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
  </div>
</template>
`,p=t({__name:"index",setup(F){return(_,u)=>{const n=d,i=o;return r(),c("div",null,[a(n,{title:"徽章",description:"FaBadge"}),a(i,{code:s(f)},{default:m(()=>[a(l)]),_:1},8,["code"])])}}});typeof e=="function"&&e(p);export{p as default};
