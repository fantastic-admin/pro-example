import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DOBSFE76.js";import"./index-CzSgqjg6.js";import"./index-BLSV4yIg.js";export{o as default};
