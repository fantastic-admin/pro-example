import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CTvzLuth.js";import"./index-xcJMzuCA.js";export{m as default};
