import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-TmHF8Dxw.js";import"./index.vue_vue_type_script_setup_true_lang-DIEW1slA.js";import"./index-H6QnEWHf.js";export{o as default};
