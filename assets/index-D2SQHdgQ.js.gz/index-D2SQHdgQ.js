import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DM51kINO.js";import"./department-DgQiHAay.js";import"./index-Dpu-vvoM.js";export{o as default};
