import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-jkJj-X_k.js";import"./index-ToPwg59K.js";import"./index-Dv6GDtcN.js";export{o as default};
