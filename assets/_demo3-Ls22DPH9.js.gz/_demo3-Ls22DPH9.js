import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Ca5XuU1_.js";import"./index.vue_vue_type_script_setup_true_lang-CimuGHFd.js";import"./index-DuOv7Qep.js";export{o as default};
