import{Z as r,n as u,x as a}from"./index-H6QnEWHf.js";function s(t){const o=r({nonce:u()});return a(()=>{var e;return(t==null?void 0:t.value)||((e=o.nonce)==null?void 0:e.value)})}export{s as u};
