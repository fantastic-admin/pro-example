import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BPSEeQVl.js";import"./index-De8Oh0HC.js";import"./index-DKzBkXCr.js";export{o as default};
