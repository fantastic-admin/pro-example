import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BzZztdMe.js";import"./index-6cBNm7O3.js";import"./index-DuOv7Qep.js";export{o as default};
