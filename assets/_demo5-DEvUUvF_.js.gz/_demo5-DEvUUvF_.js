import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C5v_xUte.js";import"./index-BHkWVPDT.js";import"./index.vue_vue_type_script_setup_true_lang-Ci9LtZ31.js";export{o as default};
