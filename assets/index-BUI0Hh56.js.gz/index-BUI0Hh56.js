import{_ as r}from"./index.vue_vue_type_script_setup_true_lang-D0Szghxo.js";import{d as p,f as c,g as m,h as e,j as o,i as t,a8 as l,l as d,V as a}from"./index-CkXBA4BI.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-BUlXT_Fv.js";import"./index-DwqvzQUS.js";import"./index.vue_vue_type_script_setup_true_lang-C-aEMREB.js";import"./index-CA_9wTA3.js";import"./index.vue_vue_type_script_setup_true_lang-gminbaCh.js";import"./index.vue_vue_type_script_setup_true_lang-CPgJBiHI.js";import"./useFormControl-tydkDHgF.js";import"./VisuallyHiddenInput-De8iY_H_.js";const f=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <div class="h-vh" />
  <FaFixedActionBar>
    <div :style="\`height: \${height[0]}px;\`" />
    <FaSlider v-model="height" />
  </FaFixedActionBar>
</template>
`,h=p({__name:"index",setup(u){return(F,n)=>{const i=l,s=r;return m(),c("div",null,[e(i,{title:"固定底部操作栏"},{description:o(()=>n[0]||(n[0]=[t("div",{class:"space-y-2"},[t("p",null,"FaFixedActionBar"),t("p",null,"避免因页面过长，导致操作按钮需要滚动到页面底部才能操作")],-1)])),_:1}),e(s,{code:d(f)},{default:o(()=>[e(_)]),_:1},8,["code"])])}}});typeof a=="function"&&a(h);export{h as default};
