import{_ as o}from"./command.vue_vue_type_script_setup_true_lang-BI2G1rHB.js";import"./index.vue_vue_type_script_setup_true_lang-DIFiN8yS.js";import"./index-DuOv7Qep.js";export{o as default};
