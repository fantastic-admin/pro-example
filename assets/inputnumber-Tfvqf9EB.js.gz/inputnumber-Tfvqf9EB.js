import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-CK3Viyuv.js";import"./index-CngbNVLW.js";export{m as default};
