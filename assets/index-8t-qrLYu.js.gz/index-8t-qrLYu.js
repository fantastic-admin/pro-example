import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C71m9hwZ.js";import"./index-8eOOZCt1.js";import"./menu-Bb4SUaWe.js";import"./role-INPp5DO0.js";export{o as default};
