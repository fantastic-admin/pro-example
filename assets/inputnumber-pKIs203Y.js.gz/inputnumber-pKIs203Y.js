import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-B_mdq2Hl.js";import"./index-Bnionyve.js";export{m as default};
