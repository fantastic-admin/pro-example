import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Dp-PSr_c.js";import"./index.vue_vue_type_script_setup_true_lang-DWHg9dT3.js";import"./index-BHkWVPDT.js";export{o as default};
