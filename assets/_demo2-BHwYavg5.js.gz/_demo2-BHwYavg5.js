import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CJKi4nNX.js";import"./index.vue_vue_type_script_setup_true_lang-Bmbwt0bm.js";import"./index-DOTJNdHl.js";export{o as default};
