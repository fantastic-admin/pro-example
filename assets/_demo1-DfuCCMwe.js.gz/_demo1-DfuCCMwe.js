import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-C17SUjnC.js";import"./index-SDO31BjC.js";import"./index-B13-Jify.js";export{o as default};
