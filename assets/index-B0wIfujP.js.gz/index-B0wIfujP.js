import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-zNw2TaTg.js";import"./department-BshbsKKa.js";import"./index-CsSDrlYc.js";export{o as default};
