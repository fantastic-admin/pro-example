import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BaKoIl5I.js";import"./index.vue_vue_type_script_setup_true_lang-C8knDJbe.js";import"./index-BFPO48W4.js";export{o as default};
