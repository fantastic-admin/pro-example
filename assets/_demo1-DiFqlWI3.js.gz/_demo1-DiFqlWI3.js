import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Cq6LkrLG.js";import"./index-Dq3cC6pk.js";import"./index-DOTJNdHl.js";export{o as default};
