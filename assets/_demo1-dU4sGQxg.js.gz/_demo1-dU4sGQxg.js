import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-C8uLJ7Gj.js";import"./index-glc1y-UY.js";import"./index-Dk37_K7O.js";export{o as default};
