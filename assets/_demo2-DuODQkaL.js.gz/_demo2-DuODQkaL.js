import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BbLuZztw.js";import"./index-DRFMav3n.js";import"./index-DYvoYzOv.js";export{o as default};
