import{_ as m}from"./input.vue_vue_type_script_setup_true_lang-B8agFUug.js";import"./index-Bnionyve.js";export{m as default};
