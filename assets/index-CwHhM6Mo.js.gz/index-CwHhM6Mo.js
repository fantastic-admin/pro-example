import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DcoIWWx-.js";import"./index-DRFMav3n.js";import"./menu-BazzcPob.js";import"./role-CIqPjAIo.js";export{o as default};
