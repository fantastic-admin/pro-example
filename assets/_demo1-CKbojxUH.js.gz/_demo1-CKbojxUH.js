import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-buY_2tVL.js";import"./index.vue_vue_type_script_setup_true_lang-BTKdCKj_.js";import"./index-CphCexG_.js";export{o as default};
