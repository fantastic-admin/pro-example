import{bN as r,g as u,M as a}from"./index-B13-Jify.js";function i(t){const o=r({nonce:u()});return a(()=>{var e;return(t==null?void 0:t.value)||((e=o.nonce)==null?void 0:e.value)})}export{i as u};
