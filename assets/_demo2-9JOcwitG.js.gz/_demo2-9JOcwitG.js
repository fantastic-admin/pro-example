import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-D0BlnJky.js";import"./index-CaDOtEIa.js";import"./index-DOTJNdHl.js";export{o as default};
