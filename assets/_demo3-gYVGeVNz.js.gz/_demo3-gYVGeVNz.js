import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CUPlNmaE.js";import"./index.vue_vue_type_script_setup_true_lang-BaoSFxjf.js";import"./index-KSDvm3cB.js";export{o as default};
