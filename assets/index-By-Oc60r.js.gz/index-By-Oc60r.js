import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BvA_tfki.js";import"./dictionary-DUpM8XF4.js";import"./index-KSDvm3cB.js";export{o as default};
