import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Ck4Cff2X.js";import"./index.vue_vue_type_script_setup_true_lang-jrjWFRJA.js";import"./index-B13-Jify.js";export{o as default};
