import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-CiA77rN-.js";import{d as c,f as s,g as i,h as e,a8 as r,j as m,l as p,V as t}from"./index-xj0hzzoN.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-C5fHUWKi.js";import"./index-BIrqzr6m.js";import"./index.vue_vue_type_script_setup_true_lang-B56Pfwy5.js";import"./nullish-CHIgUVhi.js";import"./check-BPGmov9x.js";import"./useFormControl-8P94415q.js";import"./VisuallyHiddenInput-Wp1kXxGa.js";const d=`<script setup lang="ts">
const checked = ref(false)
<\/script>

<template>
  <div class="flex gap-4">
    <FaCheckbox v-model="checked">
      复选框
    </FaCheckbox>
    {{ checked }}
  </div>
</template>
`,f=c({__name:"index",setup(l){return(h,k)=>{const o=r,n=a;return i(),s("div",null,[e(o,{title:"复选框",description:"FaCheckbox"}),e(n,{code:p(d)},{default:m(()=>[e(_)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
