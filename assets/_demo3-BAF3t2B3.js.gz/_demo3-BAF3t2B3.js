import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-D6RGdVnP.js";import"./index.vue_vue_type_script_setup_true_lang-EQAogeRR.js";import"./index-B13-Jify.js";export{o as default};
