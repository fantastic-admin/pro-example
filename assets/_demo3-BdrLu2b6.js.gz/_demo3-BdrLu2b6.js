import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BKIm6UvW.js";import"./index.vue_vue_type_script_setup_true_lang-CadMsvNT.js";import"./index-DFNzsyWB.js";export{o as default};
