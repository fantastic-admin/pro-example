import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-CCtOAovt.js";import"./index-Db5JpCpC.js";export{m as default};
