import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-I5_TbbKr.js";import"./index-BLENON4v.js";import"./index-B13-Jify.js";export{o as default};
