import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-mKU7o47A.js";import"./index-DsBWV6bR.js";import"./index-H6QnEWHf.js";export{o as default};
