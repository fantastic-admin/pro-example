import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-c_2O4j_k.js";import"./department-CigpwRTD.js";import"./index-D4ACN76T.js";export{o as default};
