import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-DZKjaEw0.js";import"./index-B13-Jify.js";import"./index.vue_vue_type_script_setup_true_lang-DbxEzmbw.js";export{o as default};
