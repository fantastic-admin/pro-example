import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CKsRnW_P.js";import"./index.vue_vue_type_script_setup_true_lang-WTLd1ZS9.js";import"./index-KSDvm3cB.js";export{o as default};
