import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CuGAkH1o.js";import"./index.vue_vue_type_script_setup_true_lang-DqQpz7BJ.js";import"./index-DFNzsyWB.js";export{o as default};
