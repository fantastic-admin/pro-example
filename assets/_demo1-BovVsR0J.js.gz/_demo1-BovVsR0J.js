import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D1Ig-EF-.js";import"./index.vue_vue_type_script_setup_true_lang-jrjWFRJA.js";import"./index-B13-Jify.js";export{o as default};
