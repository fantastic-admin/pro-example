import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BjGRQfMM.js";import"./index.vue_vue_type_script_setup_true_lang-BFZsc_bc.js";import"./index-BLSV4yIg.js";export{o as default};
