import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-D0V1yQA2.js";import"./index.vue_vue_type_script_setup_true_lang-DP9F9Ahl.js";import"./index-Dv6GDtcN.js";export{o as default};
