import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-xp3fmBWr.js";import"./index-KSDvm3cB.js";import"./menu-CAS_P7sQ.js";import"./role-BZkQn-6e.js";export{o as default};
