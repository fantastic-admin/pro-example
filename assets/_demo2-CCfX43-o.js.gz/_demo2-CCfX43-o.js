import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C7K_rO3_.js";import"./index-Dq3cC6pk.js";import"./index-DOTJNdHl.js";export{o as default};
