import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BTU7zFxR.js";import"./index.vue_vue_type_script_setup_true_lang-DvmhqQa1.js";import"./index-Bnionyve.js";export{o as default};
