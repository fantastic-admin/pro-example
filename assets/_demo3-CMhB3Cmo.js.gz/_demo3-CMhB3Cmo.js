import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CiwabCoK.js";import"./index.vue_vue_type_script_setup_true_lang-B6GZUcUG.js";import"./index-Cm5PYwOf.js";export{o as default};
