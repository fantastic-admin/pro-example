import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-AeeSokpR.js";import"./index-553qAUTx.js";import"./index.vue_vue_type_script_setup_true_lang-m8lghPJ5.js";export{o as default};
