import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BNjb6qp_.js";import"./index-553qAUTx.js";import"./role-6FPXaYG8.js";export{o as default};
