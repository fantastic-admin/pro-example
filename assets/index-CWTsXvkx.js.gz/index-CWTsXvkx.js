import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-L9dq-fPr.js";import"./dictionary-DduSTtVT.js";import"./index-BIIATpY8.js";export{o as default};
