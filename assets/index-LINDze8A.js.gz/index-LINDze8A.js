import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_K9jmdk.js";import"./index-KSDvm3cB.js";import"./role-BZkQn-6e.js";export{o as default};
