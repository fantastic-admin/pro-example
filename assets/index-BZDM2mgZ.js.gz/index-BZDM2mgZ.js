import{_ as a}from"./index.vue_vue_type_script_setup_true_lang-CnwQlPJc.js";import{d as c,f as s,g as i,h as e,a8 as r,j as m,l as p,V as t}from"./index-D4ShR5zg.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-Bzd4csrl.js";import"./index-Z-JH_SAD.js";import"./index.vue_vue_type_script_setup_true_lang-DSAN-xwO.js";import"./nullish-CHIgUVhi.js";import"./check-D36LFURU.js";import"./useFormControl-BPGkY5eQ.js";import"./VisuallyHiddenInput-CMAiJUAl.js";const d=`<script setup lang="ts">
const checked = ref(false)
<\/script>

<template>
  <div class="flex gap-4">
    <FaCheckbox v-model="checked">
      复选框
    </FaCheckbox>
    {{ checked }}
  </div>
</template>
`,f=c({__name:"index",setup(l){return(h,k)=>{const o=r,n=a;return i(),s("div",null,[e(o,{title:"复选框",description:"FaCheckbox"}),e(n,{code:p(d)},{default:m(()=>[e(_)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
