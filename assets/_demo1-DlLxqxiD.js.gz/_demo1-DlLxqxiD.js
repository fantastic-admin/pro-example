import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BqN8-FCa.js";import"./index-C1QYd_SJ.js";import"./index-8eOOZCt1.js";export{o as default};
