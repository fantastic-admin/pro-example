import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CEi_WZ49.js";import"./index.vue_vue_type_script_setup_true_lang-CimuGHFd.js";import"./index-DuOv7Qep.js";export{o as default};
