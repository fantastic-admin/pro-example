import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-ByGetD_k.js";import"./index.vue_vue_type_script_setup_true_lang-GJaJ7cXt.js";import"./index-KSDvm3cB.js";export{o as default};
