import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-DQ_uJyiP.js";import"./index.vue_vue_type_script_setup_true_lang-BrLQxncz.js";import"./index-8eOOZCt1.js";export{o as default};
