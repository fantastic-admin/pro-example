import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CcuF_Py_.js";import"./index.vue_vue_type_script_setup_true_lang-Bnn-8mdL.js";import"./index-CkXBA4BI.js";export{o as default};
