import{K as r,aR as t,aS as a}from"./index-Dv6GDtcN.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
