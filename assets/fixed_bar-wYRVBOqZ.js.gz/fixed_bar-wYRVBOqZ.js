import{A as e,Nt as t,O as n,Y as r,pt as i,w as a,x as o}from"./vue.runtime.esm-bundler-EJiOFDNb.js";import{N as s,P as c,vt as l}from"./components-Dvnhr4Ep.js";import{n as u}from"./vue-i18n.runtime-pGyDsL5y.js";import{t as d}from"./_demo1-DTTW3Gdk.js";import{t as f}from"./_demo2-BAdHSopu.js";var p=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <FaFixedBar position="top">
    <FaSlider v-model="height" />
    <div :style="\`height: \${height[0]}px;\`" />
  </FaFixedBar>
</template>
`,m=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <FaFixedBar position="bottom">
    <div :style="\`height: \${height[0]}px;\`" />
    <FaSlider v-model="height" />
  </FaFixedBar>
</template>
`,h=e({__name:`index`,setup(e){let{t:h}=u();return(e,u)=>{let g=c,_=l,v=s;return r(),a(`div`,null,[n(g,{title:t(h)(`route.component.fixedBar`)},{description:i(()=>[...u[0]||(u[0]=[o(`div`,{class:`space-y-2`},[o(`p`,null,`FaFixedBar`),o(`p`,null,`固定在页面顶部或底部，可用于展示页面信息、操作按钮等`)],-1)])]),_:1},8,[`title`]),n(_,{title:`固定在页面顶部`,code:t(p)},{default:i(()=>[n(d)]),_:1},8,[`code`]),n(_,{title:`固定在页面底部`,code:t(m)},{default:i(()=>[n(f)]),_:1},8,[`code`]),n(v,{class:`h-vh`})])}}});export{h as default};