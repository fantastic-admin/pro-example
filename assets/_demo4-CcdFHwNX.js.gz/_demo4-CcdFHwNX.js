import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-CP40hrDU.js";import"./index.vue_vue_type_script_setup_true_lang-FmiMcqxa.js";import"./index-553qAUTx.js";export{o as default};
