import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BbHxTXWD.js";import"./index-uv4b71My.js";import"./index-COkggZqL.js";export{o as default};
