import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-Cn2TFtsG.js";import"./index-CphCexG_.js";export{m as default};
