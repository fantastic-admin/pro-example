import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-z_ofvLaU.js";import"./index.vue_vue_type_script_setup_true_lang-BAcDkc1k.js";import"./index-DRFMav3n.js";export{o as default};
