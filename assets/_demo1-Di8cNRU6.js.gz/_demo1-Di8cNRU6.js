import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CkGmmHag.js";import"./index-BRDkT_K9.js";import"./index-H6QnEWHf.js";export{o as default};
