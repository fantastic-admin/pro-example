import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CzLuq6ka.js";import"./index-Ij-fB6K7.js";import"./index-Dk37_K7O.js";export{o as default};
