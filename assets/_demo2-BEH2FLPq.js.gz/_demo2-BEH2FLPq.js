import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CpHl_bp5.js";import"./index.vue_vue_type_script_setup_true_lang-B2IBEkRN.js";import"./index-xj0hzzoN.js";export{o as default};
