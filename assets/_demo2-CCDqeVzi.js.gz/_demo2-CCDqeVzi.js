import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-B5UbSkGo.js";import"./index.vue_vue_type_script_setup_true_lang-CvnRx29j.js";import"./index-BHkWVPDT.js";export{o as default};
