import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-DpUwUg69.js";import"./index-DOTJNdHl.js";import"./index.vue_vue_type_script_setup_true_lang-CiIwUTJ9.js";export{o as default};
