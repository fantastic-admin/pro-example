import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CreID-e7.js";import"./index-WlNgMWD1.js";import"./index-DOTJNdHl.js";export{o as default};
