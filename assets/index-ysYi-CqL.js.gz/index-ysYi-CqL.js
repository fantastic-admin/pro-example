import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DTwN1Qns.js";import"./index-H6QnEWHf.js";import"./menu-Tj77A3rN.js";import"./role-Drh3e6Yh.js";export{o as default};
