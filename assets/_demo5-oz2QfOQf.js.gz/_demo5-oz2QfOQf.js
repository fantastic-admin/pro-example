import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-CUUR9UfY.js";import"./index.vue_vue_type_script_setup_true_lang-BHfomNw9.js";import"./index-H6KsPIiT.js";export{o as default};
