import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Bl0mmDaK.js";import"./index.vue_vue_type_script_setup_true_lang-DluA_T8K.js";import"./index-Bhq0NWKR.js";export{o as default};
