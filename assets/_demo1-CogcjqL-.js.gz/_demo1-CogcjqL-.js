import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-FW9cY8qQ.js";import"./index-CEcMOYC7.js";import"./index-xj0hzzoN.js";export{o as default};
