import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-B4auT4zu.js";import"./index-DwnayVLk.js";import"./index-BHkWVPDT.js";export{o as default};
