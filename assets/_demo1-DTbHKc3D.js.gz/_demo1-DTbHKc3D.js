import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CO3GJIV2.js";import"./index.vue_vue_type_script_setup_true_lang-BG3F60_p.js";import"./index-DOTJNdHl.js";export{o as default};
