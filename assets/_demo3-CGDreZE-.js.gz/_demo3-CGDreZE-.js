import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BmGm-aXW.js";import"./index.vue_vue_type_script_setup_true_lang-CRfMg4KW.js";import"./index-xj0hzzoN.js";export{o as default};
