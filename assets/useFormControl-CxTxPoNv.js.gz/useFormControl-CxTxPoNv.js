import{K as r,bn as t,aY as n}from"./index-C1X-Si6V.js";function a(o){return r(()=>{var e;return t(o)?!!((e=n(o))!=null&&e.closest("form")):!0})}export{a as u};
