import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BEMmDuTN.js";import"./index-BodphlTt.js";import"./index-DRFMav3n.js";export{o as default};
