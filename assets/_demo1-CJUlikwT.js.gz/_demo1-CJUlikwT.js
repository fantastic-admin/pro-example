import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DdqqJu9e.js";import"./index-DO3wYGke.js";import"./index-Cm5PYwOf.js";export{o as default};
