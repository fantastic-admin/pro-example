import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-CZw5E_cj.js";import"./index.vue_vue_type_script_setup_true_lang-B_GuISb1.js";import"./index-Dv6GDtcN.js";export{o as default};
