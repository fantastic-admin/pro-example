import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DltvfDFZ.js";import{d as s,f as c,g as r,h as e,a8 as i,j as m,l as p,V as a}from"./index-8eOOZCt1.js";import l from"./_demo1-_GD0coOT.js";import"./index-P1b-IaR7.js";import"./useGraceArea-CrB2IdB0.js";import"./index.vue_vue_type_script_setup_true_lang-BxPkYNbS.js";const d=`<template>
  <FaHoverCard class="min-w-auto">
    <FaButton variant="link">
      @hooray
    </FaButton>
    <template #card>
      <div class="flex space-x-4">
        <FaAvatar shape="circle" src="https://github.com/vuejs.png" />
        <div class="space-y-1">
          <h4 class="text-sm font-semibold">
            @hooray
          </h4>
          <p class="text-sm">
            一个前端开发工程师
          </p>
          <div class="flex items-center pt-2">
            <FaIcon name="i-ci:calendar-days" class="mr-2 h-4 w-4 opacity-70" />
            <span class="text-xs text-muted-foreground">
              2020 年注册
            </span>
          </div>
        </div>
      </div>
    </template>
  </FaHoverCard>
</template>
`,f=s({__name:"index",setup(_){return(u,v)=>{const n=i,t=o;return r(),c("div",null,[e(n,{title:"悬浮卡片",description:"FaHoverCard"}),e(t,{code:p(d)},{default:m(()=>[e(l)]),_:1},8,["code"])])}}});typeof a=="function"&&a(f);export{f as default};
