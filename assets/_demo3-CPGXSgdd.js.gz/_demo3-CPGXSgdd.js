import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BwUjKiH9.js";import"./index.vue_vue_type_script_setup_true_lang-DDDZEyQd.js";import"./index-BFPO48W4.js";export{o as default};
