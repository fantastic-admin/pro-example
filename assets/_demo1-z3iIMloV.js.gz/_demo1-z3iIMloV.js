import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DkXBPPvH.js";import"./index.vue_vue_type_script_setup_true_lang-COgYEhAt.js";import"./index-DRFMav3n.js";export{o as default};
