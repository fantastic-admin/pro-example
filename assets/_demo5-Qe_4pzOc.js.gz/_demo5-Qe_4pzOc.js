import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C2983hO9.js";import"./index.vue_vue_type_script_setup_true_lang-DA2jPgcK.js";import"./index-CkQ8ZzMl.js";export{o as default};
