import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D_gXIfqi.js";import"./index-DODNO_Fi.js";import"./menu-8GEwHKYC.js";import"./role-0-MfpCdB.js";export{o as default};
