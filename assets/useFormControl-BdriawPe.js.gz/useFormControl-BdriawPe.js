import{K as r,bo as t,aZ as u}from"./index-ChHFYeJP.js";function n(o){return r(()=>{var e;return t(o)?!!((e=u(o))!=null&&e.closest("form")):!0})}export{n as u};
