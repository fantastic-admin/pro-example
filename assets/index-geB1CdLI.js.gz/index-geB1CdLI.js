import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-D0Szghxo.js";import{d as c,f as s,g as r,h as e,a8 as i,j as m,l as d,V as a}from"./index-CkXBA4BI.js";import p from"./_demo1-Pd5MqcMD.js";import"./index-DwqvzQUS.js";import"./index.vue_vue_type_script_setup_true_lang-4Td018-0.js";const _=`<template>
  <div class="flex gap-4">
    <FaKbd>Ctrl</FaKbd>
    <FaKbd>⌘ K</FaKbd>
  </div>
</template>
`,f=c({__name:"index",setup(l){return(u,F)=>{const t=i,o=n;return r(),s("div",null,[e(t,{title:"键盘",description:"FaKbd"}),e(o,{code:d(_)},{default:m(()=>[e(p)]),_:1},8,["code"])])}}});typeof a=="function"&&a(f);export{f as default};
