import{_ as o}from"./index-CdK171Ue.js";import{d as t,L as a,g as n}from"./index-BFPO48W4.js";const s=`<FaCard title="卡片标题" description="卡片描述" class="w-80">
  卡片内容
  <template #footer>
    卡片底部
  </template>
</FaCard>`,l=t({__name:"_demo1",setup(_){return(c,r)=>{const e=o;return n(),a(e,{code:s,class:"flex-1"})}}});export{l as _};
