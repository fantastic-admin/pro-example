import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DXpNJ-I9.js";import{d as c,f as i,g as s,h as e,a8 as r,j as m,l as _,V as t}from"./index-Cm5PYwOf.js";import p from"./_demo1-Be_zhIta.js";import"./index-DO3wYGke.js";const d=`<template>
  <div class="flex gap-4">
    <FaInteractiveButton text="Fantastic-admin" />
    <FaInteractiveButton text="Vue.js" />
  </div>
</template>
`,f=c({__name:"index",setup(l){return(u,v)=>{const n=r,a=o;return s(),i("div",null,[e(n,{title:"交互式按钮",description:"FaInteractiveButton"}),e(a,{code:_(d)},{default:m(()=>[e(p)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
