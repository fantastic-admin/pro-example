import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CKDn2tSA.js";import"./index.vue_vue_type_script_setup_true_lang-CooIpotR.js";import"./index-DuOv7Qep.js";export{o as default};
