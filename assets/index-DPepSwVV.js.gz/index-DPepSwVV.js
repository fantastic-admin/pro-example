import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C1dawkuV.js";import"./dictionary-Dr9w326U.js";import"./index-xj0hzzoN.js";export{o as default};
