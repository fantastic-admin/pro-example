import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BQ5Z6Hqc.js";import"./index.vue_vue_type_script_setup_true_lang-BkjBPcWI.js";import"./index-DODNO_Fi.js";export{o as default};
