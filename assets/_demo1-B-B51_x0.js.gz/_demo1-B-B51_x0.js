import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-B9irdibs.js";import"./index.vue_vue_type_script_setup_true_lang-DmOnSuV0.js";import"./index-CkXBA4BI.js";export{o as default};
