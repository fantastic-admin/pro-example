import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-CusmyE5R.js";import"./index-28uxndRW.js";import"./all.vue_vue_type_script_setup_true_lang-D4HXcfFz.js";export{o as default};
