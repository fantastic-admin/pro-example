import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CaxviXcK.js";import"./index.vue_vue_type_script_setup_true_lang-EFW3rPE2.js";import"./index-Dk37_K7O.js";export{o as default};
