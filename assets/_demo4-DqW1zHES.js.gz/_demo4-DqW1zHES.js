import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BuQfsrVT.js";import"./index.vue_vue_type_script_setup_true_lang-B9DvI-ik.js";import"./index-BFPO48W4.js";export{o as default};
