import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-nCQeWppC.js";import"./index-De8Oh0HC.js";export{m as default};
