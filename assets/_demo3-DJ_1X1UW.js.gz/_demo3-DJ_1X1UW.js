import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-B4pYNEdV.js";import"./index.vue_vue_type_script_setup_true_lang-CfNVMpKa.js";import"./index-DOTJNdHl.js";export{o as default};
