import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-D76aNqip.js";import"./index.vue_vue_type_script_setup_true_lang-BG3F60_p.js";import"./index-DOTJNdHl.js";export{o as default};
