import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CGMzMP_V.js";import"./index.vue_vue_type_script_setup_true_lang-DDSAMHje.js";import"./index-De8Oh0HC.js";export{o as default};
