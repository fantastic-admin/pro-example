import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DIgy8eRO.js";import"./index-BoypW2lk.js";import"./index-Bnionyve.js";export{o as default};
