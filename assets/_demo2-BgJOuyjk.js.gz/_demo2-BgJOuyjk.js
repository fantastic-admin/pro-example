import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DPqgqljx.js";import"./index-Bhq0NWKR.js";import"./index-WO9FMu7l.js";export{o as default};
