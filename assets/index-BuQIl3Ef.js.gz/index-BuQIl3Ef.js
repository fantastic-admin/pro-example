import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CTP_g0yh.js";import"./index-DQdGVpLy.js";import"./department-Dhrz2MGt.js";export{o as default};
