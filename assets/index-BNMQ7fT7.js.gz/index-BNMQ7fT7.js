import{_ as i}from"./index.vue_vue_type_script_setup_true_lang-COBuVIR5.js";import{d as p,f as c,g as m,h as n,a8 as r,j as e,l as o,V as a}from"./index-DuOv7Qep.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-DX9SWyV9.js";import{_ as l}from"./_demo2.vue_vue_type_script_setup_true_lang-DgrKVzmk.js";import"./index-B51ig3ph.js";import"./index.vue_vue_type_script_setup_true_lang-BQLdP8Ya.js";import"./VisuallyHiddenInput-DgXbAl_m.js";const f=`<script setup lang="ts">
const pin = ref('')
<\/script>

<template>
  <FaPinInput v-model="pin" />
</template>
`,d=`<script setup lang="ts">
const pin = ref('')
<\/script>

<template>
  <FaPinInput v-model="pin" :length="4" />
</template>
`,u=p({__name:"index",setup(g){return(F,P)=>{const s=r,t=i;return m(),c("div",null,[n(s,{title:"数字输入框",description:"FaPinInput"}),n(t,{code:o(f)},{default:e(()=>[n(_)]),_:1},8,["code"]),n(t,{title:"设置长度",code:o(d)},{default:e(()=>[n(l)]),_:1},8,["code"])])}}});typeof a=="function"&&a(u);export{u as default};
