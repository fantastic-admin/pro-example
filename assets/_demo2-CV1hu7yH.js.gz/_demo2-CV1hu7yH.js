import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C--sHtpW.js";import"./index-H6KsPIiT.js";import"./index-BVDsB6hc.js";export{o as default};
