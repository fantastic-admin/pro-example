import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-uDltgLI3.js";import"./dictionary-D8qxvDTh.js";import"./index-CphCexG_.js";export{o as default};
