import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-mRCzoYxc.js";import"./index.vue_vue_type_script_setup_true_lang-B2yN5A2N.js";import"./index-Bhq0NWKR.js";export{o as default};
