import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Cxq0_xaY.js";import"./index.vue_vue_type_script_setup_true_lang-DAwFEFv2.js";import"./index-28uxndRW.js";export{o as default};
