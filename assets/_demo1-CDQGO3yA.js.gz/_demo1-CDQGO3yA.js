import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BAU2oTmM.js";import"./index-B51ig3ph.js";import"./index-DuOv7Qep.js";export{o as default};
