import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-B8evIrNc.js";import"./dictionary-BwOwTCiA.js";import"./index-Bhq0NWKR.js";export{o as default};
