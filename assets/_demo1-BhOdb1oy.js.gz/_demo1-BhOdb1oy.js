import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CQkNWMt1.js";import"./index-DJqLA50Q.js";import"./index-28uxndRW.js";export{o as default};
