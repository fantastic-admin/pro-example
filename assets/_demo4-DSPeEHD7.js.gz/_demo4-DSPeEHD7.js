import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-C1dx5Qao.js";import"./index.vue_vue_type_script_setup_true_lang-DIEW1slA.js";import"./index-H6QnEWHf.js";export{o as default};
