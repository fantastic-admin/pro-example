import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Csje1C_A.js";import"./index.vue_vue_type_script_setup_true_lang-DaxKbZTJ.js";import"./index-DQdGVpLy.js";export{o as default};
