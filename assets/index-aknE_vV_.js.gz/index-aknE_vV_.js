import{_ as r}from"./index.vue_vue_type_script_setup_true_lang-DltvfDFZ.js";import{d as i,f as c,g as m,h as e,a8 as s,j as n,l as o,V as a}from"./index-8eOOZCt1.js";import d from"./_demo1-Dna2DEbY.js";import g from"./_demo2-Ba9GGaVA.js";import h from"./_demo3-DVq5cEvx.js";import p from"./_demo4-35-rwiYw.js";import"./index-P1b-IaR7.js";import"./index-weWjgqQV.js";const f=`<template>
  <h1 class="text-balance text-4xl font-bold">
    李云龙：你<FaTextHighlight class="from-indigo-300 to-purple-300 bg-gradient-to-r">
      他娘的
    </FaTextHighlight>还真是个天才！
  </h1>
</template>
`,x=`<template>
  <h1 class="text-balance text-4xl font-bold">
    圆角是<FaTextHighlight class="rounded-lg from-purple-300 to-orange-300 bg-gradient-to-r">
      最好
    </FaTextHighlight>的。
  </h1>
</template>
`,_=`<template>
  <h1 class="text-balance text-4xl font-bold">
    使用系统主题色，你可以尝试<FaTextHighlight style="background-image: linear-gradient(45deg, hsl(var(--primary)) 0%, hsl(var(--accent)) 100%);">
      更改系统主题色
    </FaTextHighlight>。
  </h1>
</template>
`,u=`<template>
  <h1 class="text-4xl font-bold">
    这段文字<FaTextHighlight
      class="rounded-xl from-green-300 to-blue-300 bg-gradient-to-r"
      text-end-color="hsl(var(--accent))"
    >
      会随着文本颜色变化
    </FaTextHighlight>，不信你看。
  </h1>
</template>
`,b=i({__name:"index",setup(F){return(H,T)=>{const l=s,t=r;return m(),c("div",null,[e(l,{title:"文字高亮",description:"FaTextHightlight"}),e(t,{code:o(f)},{default:n(()=>[e(d)]),_:1},8,["code"]),e(t,{code:o(x)},{default:n(()=>[e(g)]),_:1},8,["code"]),e(t,{code:o(_)},{default:n(()=>[e(h)]),_:1},8,["code"]),e(t,{code:o(u)},{default:n(()=>[e(p)]),_:1},8,["code"])])}}});typeof a=="function"&&a(b);export{b as default};
