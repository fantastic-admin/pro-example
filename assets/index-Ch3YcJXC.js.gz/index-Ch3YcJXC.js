import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-LxXGgRr4.js";import"./index-Bhq0NWKR.js";import"./department-DXKWuSpb.js";export{o as default};
