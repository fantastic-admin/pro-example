import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BizYCTVa.js";import"./index.vue_vue_type_script_setup_true_lang-CHMWgUly.js";import"./index-H6KsPIiT.js";export{o as default};
