import{_ as s}from"./index.vue_vue_type_script_setup_true_lang-BhnjE5ZP.js";import{d as c,f as r,g as i,h as e,a8 as p,j as a,l as o,V as n}from"./index-KSDvm3cB.js";import l from"./_demo1-DoSVyIzK.js";import d from"./_demo2-BfWMsf-l.js";import _ from"./_demo3-BuU8twoi.js";import"./index-Cr9jXCSR.js";import"./index.vue_vue_type_script_setup_true_lang-Bs4Dd-ic.js";const f=`<template>
  <FaSparklesText text="Fantastic-admin" />
</template>
`,u=`<template>
  <FaSparklesText text="Fantastic-admin" :sparkles-count="50" />
</template>
`,x=`<template>
  <FaSparklesText text="Fantastic-admin" :colors="{ first: '#FF6B6B', second: '#4ECDC4' }" />
</template>
`,F=c({__name:"index",setup(k){return(D,w)=>{const m=p,t=s;return i(),r("div",null,[e(m,{title:"闪烁文字",description:"FaSparklesText"}),e(t,{code:o(f)},{default:a(()=>[e(l)]),_:1},8,["code"]),e(t,{title:"数量",code:o(u)},{default:a(()=>[e(d)]),_:1},8,["code"]),e(t,{title:"颜色",code:o(x)},{default:a(()=>[e(_)]),_:1},8,["code"])])}}});typeof n=="function"&&n(F);export{F as default};
