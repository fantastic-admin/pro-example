import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-4MbXWsbL.js";import"./index.vue_vue_type_script_setup_true_lang-DAnIIlxO.js";import"./index-DOTJNdHl.js";export{o as default};
