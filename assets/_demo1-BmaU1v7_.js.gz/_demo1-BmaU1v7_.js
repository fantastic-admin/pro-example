import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D6UuxG0P.js";import"./index-BIL8Ex7N.js";import"./index-B13-Jify.js";export{o as default};
