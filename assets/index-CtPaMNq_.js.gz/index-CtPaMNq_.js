import{_ as l}from"./index.vue_vue_type_script_setup_true_lang-D0Szghxo.js";import{d as c,f as r,g as d,h as e,a8 as m,j as a,l as n,V as o}from"./index-CkXBA4BI.js";import s from"./_demo1-C2Kj_y4z.js";import p from"./_demo2-C6Lo2Vpb.js";import"./index-DwqvzQUS.js";import"./index.vue_vue_type_script_setup_true_lang-CG1QHznO.js";const f=`<template>
  <FaSpotlightCard>
    <div class="flex flex-col gap-2 rounded p-6 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        悬停在这
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,_=`<template>
  <FaSpotlightCard :gradient-size="100" gradient-color="red" :gradient-opacity="1">
    <div class="flex flex-col gap-2 rounded p-6 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        悬停在这
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,g=c({__name:"index",setup(h){return(u,x)=>{const i=m,t=l;return d(),r("div",null,[e(i,{title:"聚光卡片",description:"FaSpotlightCard"}),e(t,{code:n(f)},{default:a(()=>[e(s)]),_:1},8,["code"]),e(t,{title:"尺寸 / 颜色 / 透明底",code:n(_)},{default:a(()=>[e(p)]),_:1},8,["code"])])}}});typeof o=="function"&&o(g);export{g as default};
