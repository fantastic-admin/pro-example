import{_ as l}from"./index.vue_vue_type_script_setup_true_lang-DXpNJ-I9.js";import{d as c,f as r,g as d,h as e,a8 as m,j as a,l as n,V as o}from"./index-Cm5PYwOf.js";import s from"./_demo1-B_QxJLi9.js";import p from"./_demo2-CpvYfbz3.js";import"./index-DO3wYGke.js";import"./index.vue_vue_type_script_setup_true_lang-D9F6UAM8.js";const f=`<template>
  <FaSpotlightCard>
    <div class="flex flex-col gap-2 rounded p-6 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        悬停在这
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,_=`<template>
  <FaSpotlightCard :gradient-size="100" gradient-color="red" :gradient-opacity="1">
    <div class="flex flex-col gap-2 rounded p-6 lg:p-8">
      <FaIcon name="i-ri:magic-line" class="h-8 w-8" />
      <h1 class="text-2xl font-medium">
        悬停在这
      </h1>
    </div>
  </FaSpotlightCard>
</template>
`,g=c({__name:"index",setup(h){return(u,x)=>{const i=m,t=l;return d(),r("div",null,[e(i,{title:"聚光卡片",description:"FaSpotlightCard"}),e(t,{code:n(f)},{default:a(()=>[e(s)]),_:1},8,["code"]),e(t,{title:"尺寸 / 颜色 / 透明底",code:n(_)},{default:a(()=>[e(p)]),_:1},8,["code"])])}}});typeof o=="function"&&o(g);export{g as default};
