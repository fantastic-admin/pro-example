import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-Z4gcP7mo.js";import"./index.vue_vue_type_script_setup_true_lang-M1XDxl3e.js";import"./index-Bhq0NWKR.js";export{o as default};
