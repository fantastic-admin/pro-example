import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-CiA77rN-.js";import{d as c,f as s,g as r,h as e,a8 as i,j as m,l as d,V as a}from"./index-xj0hzzoN.js";import p from"./_demo1-H27maXIL.js";import"./index-BIrqzr6m.js";import"./index.vue_vue_type_script_setup_true_lang-BrYkdmVP.js";const _=`<template>
  <div class="flex gap-4">
    <FaKbd>Ctrl</FaKbd>
    <FaKbd>⌘ K</FaKbd>
  </div>
</template>
`,f=c({__name:"index",setup(l){return(u,F)=>{const t=i,o=n;return r(),s("div",null,[e(t,{title:"键盘",description:"FaKbd"}),e(o,{code:d(_)},{default:m(()=>[e(p)]),_:1},8,["code"])])}}});typeof a=="function"&&a(f);export{f as default};
