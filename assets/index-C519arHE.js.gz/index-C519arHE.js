import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Rl10omfJ.js";import"./index-DOTJNdHl.js";import"./menu-BXbvuUG_.js";import"./role-BQ9e8Jcw.js";export{o as default};
