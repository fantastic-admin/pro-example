import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-EGjVf_u_.js";import"./index-BFlPznT8.js";import"./index-DQdGVpLy.js";export{o as default};
