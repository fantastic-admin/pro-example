import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DjlFmfLx.js";import"./dictionary-DVgDypYf.js";import"./index-DQdGVpLy.js";export{o as default};
