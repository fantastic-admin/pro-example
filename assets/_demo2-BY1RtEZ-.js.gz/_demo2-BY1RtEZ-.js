import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C0qigaZa.js";import"./index-DS89-9e9.js";import"./index-CngbNVLW.js";export{o as default};
