import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-9sLrYhyR.js";import"./index.vue_vue_type_script_setup_true_lang-AXuHRS2d.js";import"./index-28uxndRW.js";export{o as default};
