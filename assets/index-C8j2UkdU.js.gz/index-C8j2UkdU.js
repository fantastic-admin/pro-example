import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-OHCdQBrt.js";import"./dictionary-BQFy09mG.js";import"./index-C1X-Si6V.js";export{o as default};
