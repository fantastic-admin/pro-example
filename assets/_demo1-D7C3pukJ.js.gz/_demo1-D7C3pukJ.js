import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-LVim9BbQ.js";import"./index.vue_vue_type_script_setup_true_lang-BgoLOkBf.js";import"./index-BLSV4yIg.js";export{o as default};
