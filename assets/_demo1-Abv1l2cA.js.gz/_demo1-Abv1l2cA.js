import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DPEBzanK.js";import"./index.vue_vue_type_script_setup_true_lang-C4t6rfVP.js";import"./index-BLSV4yIg.js";export{o as default};
