import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-C6wYKt3F.js";import"./index.vue_vue_type_script_setup_true_lang-slzOpySM.js";import"./index-8eOOZCt1.js";export{o as default};
