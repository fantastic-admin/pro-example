import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BimpYF8-.js";import"./index.vue_vue_type_script_setup_true_lang-BU9lGi1I.js";import"./index-DRFMav3n.js";export{o as default};
