import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-BDe66Pc6.js";import"./index-xcJMzuCA.js";import"./all.vue_vue_type_script_setup_true_lang-CTgF9LoZ.js";export{o as default};
