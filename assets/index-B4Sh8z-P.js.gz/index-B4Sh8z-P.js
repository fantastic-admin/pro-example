import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BsGE8B0l.js";import"./department-BnKc7Whc.js";import"./index-DMc4HI8f.js";export{o as default};
