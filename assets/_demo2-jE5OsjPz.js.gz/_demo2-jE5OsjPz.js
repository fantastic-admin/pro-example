import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-zON3wCAi.js";import"./index.vue_vue_type_script_setup_true_lang-D4gosICD.js";import"./index-DFNzsyWB.js";export{o as default};
