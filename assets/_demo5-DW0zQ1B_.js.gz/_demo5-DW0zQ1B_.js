import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-xUZ4o1FW.js";import"./index.vue_vue_type_script_setup_true_lang-WTLd1ZS9.js";import"./index-KSDvm3cB.js";export{o as default};
