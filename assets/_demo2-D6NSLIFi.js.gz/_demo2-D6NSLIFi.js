import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BgZPrbP9.js";import"./index-CCbyaaXX.js";import"./index-DFNzsyWB.js";export{o as default};
