import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DZ-r5gik.js";import"./dictionary-BrQGteeS.js";import"./index-28uxndRW.js";export{o as default};
