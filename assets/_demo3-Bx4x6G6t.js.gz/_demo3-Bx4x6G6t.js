import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-Bk69mXps.js";import"./index.vue_vue_type_script_setup_true_lang-5SoKB9PK.js";import"./index-Dk37_K7O.js";export{o as default};
