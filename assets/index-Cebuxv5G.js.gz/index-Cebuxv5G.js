import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-PJOUmd9b.js";import"./dictionary-aYuzE4s6.js";import"./index-B13-Jify.js";export{o as default};
