import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-ClDbQwc8.js";import"./dictionary-Sat2-7xP.js";import"./index-ChHFYeJP.js";export{o as default};
