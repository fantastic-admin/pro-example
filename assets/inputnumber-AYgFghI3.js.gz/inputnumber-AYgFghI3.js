import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-uVAa_C7v.js";import"./index-xj0hzzoN.js";export{m as default};
