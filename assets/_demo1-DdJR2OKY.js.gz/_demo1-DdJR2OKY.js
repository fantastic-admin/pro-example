import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-9nxgB4o3.js";import"./index.vue_vue_type_script_setup_true_lang-5SoKB9PK.js";import"./index-Dk37_K7O.js";export{o as default};
