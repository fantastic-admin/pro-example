import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-C4ijLwCe.js";import"./index-CkXBA4BI.js";import"./all.vue_vue_type_script_setup_true_lang-DCpCE7e5.js";export{o as default};
