import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DLXplAly.js";import"./index-xj0hzzoN.js";import"./menu-CAyHPf0e.js";import"./role-BFD31saW.js";export{o as default};
