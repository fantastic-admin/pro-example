import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-z3DPDC4I.js";import"./dictionary-2rfPmV2q.js";import"./index-H6QnEWHf.js";export{o as default};
