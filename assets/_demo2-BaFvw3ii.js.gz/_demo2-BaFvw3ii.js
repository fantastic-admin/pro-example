import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-By2bGu90.js";import"./index-BbvEZFju.js";import"./index-DFNzsyWB.js";export{o as default};
