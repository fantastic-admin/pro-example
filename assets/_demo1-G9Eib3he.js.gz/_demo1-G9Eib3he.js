import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CJld174k.js";import"./index-CZP1Wbzd.js";import"./index-553qAUTx.js";export{o as default};
