import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-GsAxjYDp.js";import"./index-CngbNVLW.js";import"./menu-Dbm3_org.js";import"./role-DHJOjquo.js";export{o as default};
