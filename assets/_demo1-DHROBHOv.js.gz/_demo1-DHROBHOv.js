import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Dngt3gez.js";import"./index.vue_vue_type_script_setup_true_lang-BgBtipMd.js";import"./index-CkQ8ZzMl.js";export{o as default};
