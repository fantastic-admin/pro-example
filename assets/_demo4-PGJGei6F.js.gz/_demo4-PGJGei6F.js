import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Dag6Hmpo.js";import"./index.vue_vue_type_script_setup_true_lang-CXX3tmmW.js";import"./index-BHkWVPDT.js";export{o as default};
