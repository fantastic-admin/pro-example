import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-B2y06mDI.js";import"./index.vue_vue_type_script_setup_true_lang-DaiTplGY.js";import"./index-H6QnEWHf.js";export{o as default};
