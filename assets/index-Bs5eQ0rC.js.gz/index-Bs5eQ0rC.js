import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dk_Qexzj.js";import"./dictionary-CIFFlKoq.js";import"./index-DRFMav3n.js";export{o as default};
