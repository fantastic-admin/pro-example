import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Iwuy34Ub.js";import"./index-D_fQUYQp.js";import"./index-28uxndRW.js";export{o as default};
