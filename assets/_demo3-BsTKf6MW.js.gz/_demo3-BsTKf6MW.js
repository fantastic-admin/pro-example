import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BZLwQ13x.js";import"./index.vue_vue_type_script_setup_true_lang-DqSuMuz2.js";import"./index-BHkWVPDT.js";export{o as default};
