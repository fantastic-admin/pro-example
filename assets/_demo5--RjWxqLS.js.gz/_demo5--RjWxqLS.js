import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BVTTLfma.js";import"./index-DRFMav3n.js";import"./index.vue_vue_type_script_setup_true_lang-DIuqnNIj.js";export{o as default};
