import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CPlEMqTF.js";import"./index.vue_vue_type_script_setup_true_lang-DxsWcl0R.js";import"./index-CngbNVLW.js";export{o as default};
