import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CLVd-mn9.js";import{d as s,f as i,g as r,h as e,a8 as c,j as d,l,V as t}from"./index-553qAUTx.js";import m from"./_demo1-p-EI9ERd.js";import"./index-BAF4f9Xa.js";const p=`<template>
  <div class="h-100 flex items-center justify-center">
    <div class="mx-auto text-4xl text-neutral-600 font-semibold dark:text-neutral-400">
      Vue.js 是一款
      <FaFlipWords
        :words="['渐进式', '易上手的', '高性能', '多功能']"
        :duration="3000"
        class="text-4xl !text-primary"
      />
      JavaScript 框架
      <div class="mt-4">
        用于构建现代 Web 应用
      </div>
    </div>
  </div>
</template>
`,_=s({__name:"index",setup(f){return(u,x)=>{const n=c,a=o;return r(),i("div",null,[e(n,{title:"翻转文字",description:"FaFlipWords"}),e(a,{code:l(p)},{default:d(()=>[e(m)]),_:1},8,["code"])])}}});typeof t=="function"&&t(_);export{_ as default};
