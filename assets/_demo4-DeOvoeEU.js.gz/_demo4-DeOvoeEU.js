import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BxsFEO6N.js";import"./index.vue_vue_type_script_setup_true_lang-CS_Yf9YL.js";import"./index-D4ShR5zg.js";export{o as default};
