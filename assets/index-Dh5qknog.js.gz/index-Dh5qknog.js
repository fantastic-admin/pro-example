import{_ as r}from"./index.vue_vue_type_script_setup_true_lang-BmDYF_lz.js";import{d as p,e as c,f as m,g as e,i as o,h as t,a7 as d,k as l,U as i}from"./index-DOTJNdHl.js";import{_}from"./_demo1.vue_vue_type_script_setup_true_lang-DO-Xr6BS.js";import"./index-WlNgMWD1.js";import"./index.vue_vue_type_script_setup_true_lang-u1nFBSz6.js";import"./index-DQFPNcIV.js";import"./index.vue_vue_type_script_setup_true_lang-D3mOhxlr.js";import"./index.vue_vue_type_script_setup_true_lang-W616Q0XK.js";import"./useGraceArea-BvRdXZoy.js";import"./useFormControl-DKN6_fpZ.js";import"./VisuallyHiddenInput-C3e68TnC.js";const f=`<script setup lang="ts">
const height = ref([50])
<\/script>

<template>
  <div class="h-vh" />
  <FaFixedActionBar>
    <div :style="\`height: \${height[0]}px;\`" />
    <FaSlider v-model="height" />
  </FaFixedActionBar>
</template>
`,h=p({__name:"index",setup(u){return(F,n)=>{const a=d,s=r;return m(),c("div",null,[e(a,{title:"固定底部操作栏"},{description:o(()=>n[0]||(n[0]=[t("div",{class:"space-y-2"},[t("p",null,"FaFixedActionBar"),t("p",null,"避免因页面过长，导致操作按钮需要滚动到页面底部才能操作")],-1)])),_:1}),e(s,{code:l(f)},{default:o(()=>[e(_)]),_:1},8,["code"])])}}});typeof i=="function"&&i(h);export{h as default};
