import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BSWytD5b.js";import"./index-De8Oh0HC.js";import"./department-BQTirUz9.js";export{o as default};
