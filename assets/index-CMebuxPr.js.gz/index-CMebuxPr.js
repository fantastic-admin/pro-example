import{_ as p}from"./index.vue_vue_type_script_setup_true_lang-CnwQlPJc.js";import{d as s,f as m,g as r,h as e,a8 as i,j as t,l as o,V as a}from"./index-D4ShR5zg.js";import l from"./_demo1-_moZ3_nb.js";import{_ as f}from"./_demo2.vue_vue_type_script_setup_true_lang-C3D7aNY7.js";import"./index-Z-JH_SAD.js";import"./index.vue_vue_type_script_setup_true_lang-CJcHuMg_.js";const _=`<template>
  <FaPopover>
    <FaButton>
      浮动面板
      <FaIcon name="i-ep:caret-bottom" />
    </FaButton>
    <template #panel>
      <div class="h-30 w-60 flex items-center justify-center">
        面板内容
      </div>
    </template>
  </FaPopover>
</template>
`,d=`<script setup lang="ts">
const open = ref(false)
<\/script>

<template>
  <FaPopover v-model:open="open">
    <FaButton>
      浮动面板
      <FaIcon name="i-ep:caret-bottom" />
    </FaButton>
    <template #panel>
      <div class="h-30 w-60 flex items-center justify-center">
        <FaButton @click="open = false">
          关闭
        </FaButton>
      </div>
    </template>
  </FaPopover>
</template>
`,u=s({__name:"index",setup(F){return(v,B)=>{const c=i,n=p;return r(),m("div",null,[e(c,{title:"浮动面板",description:"FaPopover"}),e(n,{code:o(_)},{default:t(()=>[e(l)]),_:1},8,["code"]),e(n,{title:"手动关闭",code:o(d)},{default:t(()=>[e(f)]),_:1},8,["code"])])}}});typeof a=="function"&&a(u);export{u as default};
