import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BceryrU5.js";import"./dictionary-BDc2wW3A.js";import"./index-DuOv7Qep.js";export{o as default};
