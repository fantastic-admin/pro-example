import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DXqpJTSY.js";import"./index.vue_vue_type_script_setup_true_lang-BJj9uh_S.js";import"./index-BLSV4yIg.js";export{o as default};
