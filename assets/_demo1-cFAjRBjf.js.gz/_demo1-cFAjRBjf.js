import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DZK2i4ZD.js";import"./index.vue_vue_type_script_setup_true_lang-BGM6I5J3.js";import"./index-B13-Jify.js";export{o as default};
