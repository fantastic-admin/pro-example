import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C4-vZZDV.js";import"./index-BFPO48W4.js";import"./index.vue_vue_type_script_setup_true_lang-Bw7LbY8M.js";export{o as default};
