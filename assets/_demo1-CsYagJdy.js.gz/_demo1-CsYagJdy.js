import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D2l1_gEa.js";import"./index-DUEj3OrR.js";import"./index-COkggZqL.js";export{o as default};
