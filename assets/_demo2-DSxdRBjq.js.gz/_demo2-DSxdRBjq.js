import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BS3_nP9l.js";import"./index.vue_vue_type_script_setup_true_lang-Bm3PN544.js";import"./index-BHkWVPDT.js";export{o as default};
