import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-3jgbrPsF.js";import"./index.vue_vue_type_script_setup_true_lang-DpI2MMFc.js";import"./index-CngbNVLW.js";export{o as default};
