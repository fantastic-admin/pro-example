import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-D-vpG7S1.js";import"./index.vue_vue_type_script_setup_true_lang-DWHg9dT3.js";import"./index-BHkWVPDT.js";export{o as default};
