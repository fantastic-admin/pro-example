import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-DV0o8Uxq.js";import"./index.vue_vue_type_script_setup_true_lang-Cw1zTAMb.js";import"./index-CphCexG_.js";export{o as default};
