import{_ as n}from"./index.vue_vue_type_script_setup_true_lang-g8w5HU-G.js";import{d as r,e as c,f as s,g as e,a7 as i,i as m,k as p,U as t}from"./index-CkQ8ZzMl.js";import _ from"./_demo1-BzMlYkt3.js";import"./index-CAaXm9bO.js";import"./index.vue_vue_type_script_setup_true_lang-oLl-7b2p.js";const d=`<template>
  <FaCard title="卡片标题" description="卡片描述" class="w-80">
    卡片内容
    <template #footer>
      卡片底部
    </template>
  </FaCard>
</template>
`,f=r({__name:"index",setup(l){return(u,C)=>{const a=i,o=n;return s(),c("div",null,[e(a,{title:"卡片",description:"FaCard"}),e(o,{code:p(d)},{default:m(()=>[e(_)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
