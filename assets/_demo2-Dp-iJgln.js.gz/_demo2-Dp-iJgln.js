import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CrKw5JT1.js";import"./index.vue_vue_type_script_setup_true_lang-B_41NZCG.js";import"./index-Dk37_K7O.js";export{o as default};
