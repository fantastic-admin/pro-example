import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BA1GjFIo.js";import"./dictionary-C0ip_hhy.js";import"./index-DFNzsyWB.js";export{o as default};
