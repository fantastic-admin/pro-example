import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-C-5bTd5P.js";import"./index.vue_vue_type_script_setup_true_lang-CiE--HH4.js";import"./index-CphCexG_.js";export{o as default};
