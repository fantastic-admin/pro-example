import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-DNO-URDE.js";import"./index.vue_vue_type_script_setup_true_lang-Dsz-lJo2.js";import"./index-CkXBA4BI.js";export{o as default};
