import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CRP0gSq1.js";import"./index-CusCaSre.js";import"./index-DODNO_Fi.js";export{o as default};
