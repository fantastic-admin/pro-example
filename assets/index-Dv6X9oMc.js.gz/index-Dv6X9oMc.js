import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-UB4x4dnp.js";import"./index.vue_vue_type_script_setup_true_lang-CTvzLuth.js";import"./index-xcJMzuCA.js";export{o as default};
