import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DZISRV1j.js";import"./index-w6yvxCcg.js";import"./index-De8Oh0HC.js";export{o as default};
