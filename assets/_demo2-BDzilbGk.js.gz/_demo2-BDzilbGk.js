import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-tbOsfoHu.js";import"./index-COtpVyWR.js";import"./index-CkQ8ZzMl.js";export{o as default};
