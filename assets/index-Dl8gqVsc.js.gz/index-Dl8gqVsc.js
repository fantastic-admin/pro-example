import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-VzhjSsMo.js";import"./index-D4ShR5zg.js";import"./role-DZrQMdbN.js";export{o as default};
