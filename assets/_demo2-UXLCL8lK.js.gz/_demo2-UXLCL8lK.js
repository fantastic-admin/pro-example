import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DoxTqmXZ.js";import"./index-COkggZqL.js";import"./index-T3lE4WHr.js";export{o as default};
