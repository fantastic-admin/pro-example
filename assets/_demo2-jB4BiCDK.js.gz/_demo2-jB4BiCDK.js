import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C3D7aNY7.js";import"./index.vue_vue_type_script_setup_true_lang-CJcHuMg_.js";import"./index-D4ShR5zg.js";export{o as default};
