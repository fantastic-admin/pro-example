import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-B4u96pvk.js";import"./index.vue_vue_type_script_setup_true_lang-BkbVzupO.js";import"./index-DRFMav3n.js";export{o as default};
