import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-ZoSq3-Ae.js";import"./index.vue_vue_type_script_setup_true_lang-Bkq3yhtK.js";import"./index-553qAUTx.js";export{o as default};
