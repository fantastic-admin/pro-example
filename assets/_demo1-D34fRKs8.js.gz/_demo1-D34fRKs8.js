import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DyjDDPWR.js";import"./index.vue_vue_type_script_setup_true_lang-CA7JtHGm.js";import"./index-xj0hzzoN.js";export{o as default};
