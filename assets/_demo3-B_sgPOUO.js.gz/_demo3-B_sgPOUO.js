import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-EfCxPw6F.js";import"./index.vue_vue_type_script_setup_true_lang-DwNki4sp.js";import"./index-Bnionyve.js";export{o as default};
