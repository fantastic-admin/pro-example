import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BCOQOPV9.js";import"./index-rxnjw9Eu.js";import"./index-553qAUTx.js";export{o as default};
