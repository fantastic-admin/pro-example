import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BmDYF_lz.js";import{d as a,e as r,f as s,g as e,a7 as c,i as d,k as m,U as t}from"./index-DOTJNdHl.js";import p from"./_demo1-Dx5JrSSg.js";import"./index-WlNgMWD1.js";const _=`<template>
  <FaDivider>center</FaDivider>
  <FaDivider position="start">
    left
  </FaDivider>
  <FaDivider position="end">
    right
  </FaDivider>
</template>
`,f=a({__name:"index",setup(l){return(v,D)=>{const n=c,i=o;return s(),r("div",null,[e(n,{title:"分割线",description:"FaDivider"}),e(i,{code:m(_)},{default:d(()=>[e(p)]),_:1},8,["code"])])}}});typeof t=="function"&&t(f);export{f as default};
