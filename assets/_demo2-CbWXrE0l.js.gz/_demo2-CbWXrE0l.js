import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C5VmOgam.js";import"./index-CngbNVLW.js";import"./index-BQrxBG34.js";export{o as default};
