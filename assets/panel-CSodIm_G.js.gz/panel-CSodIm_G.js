import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-DFmnJFkA.js";import"./index-BFPO48W4.js";import"./all.vue_vue_type_script_setup_true_lang-CTeI5NBm.js";export{o as default};
