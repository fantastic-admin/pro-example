import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DJG-het0.js";import"./index.vue_vue_type_script_setup_true_lang-BPKQEuGJ.js";import"./index-8eOOZCt1.js";export{o as default};
