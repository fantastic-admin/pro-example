import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Bj3qsmkQ.js";import"./department-DndPB2EG.js";import"./index-8eOOZCt1.js";export{o as default};
