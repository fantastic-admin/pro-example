import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-C0rS12HG.js";import"./index.vue_vue_type_script_setup_true_lang-BknbM85t.js";import"./index-Bnionyve.js";export{o as default};
