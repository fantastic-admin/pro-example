import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-BcRtWf_e.js";import"./index-DFNzsyWB.js";import"./index.vue_vue_type_script_setup_true_lang-DIWSstrB.js";export{o as default};
