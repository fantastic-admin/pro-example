import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DkhhVWbK.js";import"./index.vue_vue_type_script_setup_true_lang-DWvx_OJw.js";import"./index-COkggZqL.js";export{o as default};
