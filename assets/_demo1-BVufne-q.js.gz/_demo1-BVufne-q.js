import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-iuk4aT83.js";import"./index-BAF4f9Xa.js";import"./index-553qAUTx.js";export{o as default};
