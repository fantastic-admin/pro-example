import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-I1EE_GLN.js";import"./index.vue_vue_type_script_setup_true_lang-1CLKt3V9.js";import"./index-553qAUTx.js";export{o as default};
