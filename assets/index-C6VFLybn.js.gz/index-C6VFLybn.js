import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BjZDP3T6.js";import"./dictionary-Dlp_vG1G.js";import"./index-CkQ8ZzMl.js";export{o as default};
