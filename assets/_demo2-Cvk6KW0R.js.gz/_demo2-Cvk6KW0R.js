import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Xbjh8LWg.js";import"./index.vue_vue_type_script_setup_true_lang-CmIostjS.js";import"./index-DQdGVpLy.js";export{o as default};
