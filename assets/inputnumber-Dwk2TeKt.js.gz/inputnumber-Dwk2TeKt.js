import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-CjMUdjDr.js";import"./index-Dpu-vvoM.js";export{m as default};
