import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-1TwtD1SY.js";import"./index-CsSDrlYc.js";import"./menu-CnKLR9IQ.js";import"./role-BH8JCdwA.js";export{o as default};
