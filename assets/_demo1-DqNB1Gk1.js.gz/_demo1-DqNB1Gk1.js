import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-zOjmCgNa.js";import"./index-Ci0lfOFO.js";import"./index-Bnionyve.js";export{o as default};
