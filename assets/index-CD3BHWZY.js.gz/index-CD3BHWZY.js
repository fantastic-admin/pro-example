import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DCqhLxNQ.js";import"./index-Bnionyve.js";import"./department-Bc3_Lksl.js";export{o as default};
