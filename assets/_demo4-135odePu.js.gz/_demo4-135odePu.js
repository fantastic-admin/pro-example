import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-BEW6Yn9h.js";import"./index.vue_vue_type_script_setup_true_lang-M1XDxl3e.js";import"./index-Bhq0NWKR.js";export{o as default};
