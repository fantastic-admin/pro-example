import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-omY6ng-q.js";import"./index-DjlfmGro.js";import"./index-CkXBA4BI.js";export{o as default};
