import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BISQV6xo.js";import"./index.vue_vue_type_script_setup_true_lang-Dq3D-Uwc.js";import"./index-DFNzsyWB.js";export{o as default};
