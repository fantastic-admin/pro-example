import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-BP8adQnt.js";import"./dictionary-Cg7PJ2uf.js";import"./index-CsSDrlYc.js";export{o as default};
