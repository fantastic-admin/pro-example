import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-72hpeSKY.js";import"./index.vue_vue_type_script_setup_true_lang-BWdxqDq8.js";import"./index-D4ShR5zg.js";export{o as default};
