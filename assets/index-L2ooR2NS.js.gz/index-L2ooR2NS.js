import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-biUvpi7-.js";import"./index-DFNzsyWB.js";import"./department-BCqBDXlh.js";export{o as default};
