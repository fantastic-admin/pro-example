import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DPOY_SzY.js";import"./index.vue_vue_type_script_setup_true_lang-DAwFEFv2.js";import"./index-28uxndRW.js";export{o as default};
