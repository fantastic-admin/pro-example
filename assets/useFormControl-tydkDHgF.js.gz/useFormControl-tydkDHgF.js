import{K as r,aT as t,aU as a}from"./index-CkXBA4BI.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
