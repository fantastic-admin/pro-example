import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CXnmRjJD.js";import"./index-DOTJNdHl.js";import"./department-Bb3ZMqfd.js";export{o as default};
