import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-tQO-rxbn.js";import"./index.vue_vue_type_script_setup_true_lang-DiSnMjV5.js";import"./index-CkQ8ZzMl.js";export{o as default};
