import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BOj-91Vb.js";import"./index-D9VOWEz9.js";import"./index-28uxndRW.js";export{o as default};
