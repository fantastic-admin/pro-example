import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-C_9wmaul.js";import"./department-BeE-pzoK.js";import"./index-Bbf2k3Iz.js";export{o as default};
