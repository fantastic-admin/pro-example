import{A as e,Nt as t,O as n,Y as r,pt as i,w as a}from"./vue.runtime.esm-bundler-EJiOFDNb.js";import{P as o,vt as s}from"./components-Dvnhr4Ep.js";import{n as c}from"./vue-i18n.runtime-pGyDsL5y.js";import{t as l}from"./_demo1-C22d2EpE.js";var u=`<template>
  <div class="flex gap-4">
    <FaGradientButton>Fantastic-admin 起飞! 🚀🚀🚀</FaGradientButton>
    <FaGradientButton :duration="500">
      速度更快
    </FaGradientButton>
    <FaGradientButton :colors="['#000', '#fff']">
      自定义颜色
    </FaGradientButton>
    <FaGradientButton class="p-2">
      加粗边框
    </FaGradientButton>
  </div>
</template>
`,d=e({__name:`index`,setup(e){let{t:d}=c();return(e,c)=>{let f=o,p=s;return r(),a(`div`,null,[n(f,{title:t(d)(`route.component.gradientButton`),description:`FaGradientButton`},null,8,[`title`]),n(p,{code:t(u)},{default:i(()=>[n(l)]),_:1},8,[`code`])])}}});export{d as default};