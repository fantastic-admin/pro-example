import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CV3AW1zH.js";import"./index.vue_vue_type_script_setup_true_lang-DdWswJe2.js";import"./index-COkggZqL.js";export{o as default};
