import{_ as o}from"./_demo5.vue_vue_type_script_setup_true_lang-DRc79Ou5.js";import"./index-CkXBA4BI.js";import"./index.vue_vue_type_script_setup_true_lang-C3wM19Ih.js";export{o as default};
