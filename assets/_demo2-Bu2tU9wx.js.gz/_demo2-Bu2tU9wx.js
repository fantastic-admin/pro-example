import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-lS18VQcJ.js";import"./index-C_D_bBIO.js";import"./index-BHkWVPDT.js";export{o as default};
