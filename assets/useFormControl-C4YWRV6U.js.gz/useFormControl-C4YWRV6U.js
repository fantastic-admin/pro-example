import{K as r,aV as t,aW as a}from"./index-Dpu-vvoM.js";function n(o){return r(()=>{var e;return t(o)?!!((e=a(o))!=null&&e.closest("form")):!0})}export{n as u};
