import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CwYUohgs.js";import"./department-BjD0Ag54.js";import"./index-DgIgHwyh.js";export{o as default};
