import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DcWpXFvj.js";import"./index.vue_vue_type_script_setup_true_lang-DyREfqFn.js";import"./index-DOTJNdHl.js";export{o as default};
