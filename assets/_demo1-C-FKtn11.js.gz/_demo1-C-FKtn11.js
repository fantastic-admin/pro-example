import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D43rFiqh.js";import"./index-B8fOkv0d.js";import"./index-De8Oh0HC.js";export{o as default};
