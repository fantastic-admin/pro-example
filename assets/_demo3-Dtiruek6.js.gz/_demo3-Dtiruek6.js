import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-BSM7Mosw.js";import"./index.vue_vue_type_script_setup_true_lang-CLYFwZ9h.js";import"./index-553qAUTx.js";export{o as default};
