import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-C-fpLLcY.js";import"./index.vue_vue_type_script_setup_true_lang-CQp7nryK.js";import"./index-553qAUTx.js";export{o as default};
