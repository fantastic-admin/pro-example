import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Bh2TQTQV.js";import"./index-BbvEZFju.js";import"./index-DFNzsyWB.js";export{o as default};
