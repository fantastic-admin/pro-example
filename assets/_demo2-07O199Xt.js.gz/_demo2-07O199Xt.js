import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BKVcNajq.js";import"./index.vue_vue_type_script_setup_true_lang-DujU3vNg.js";import"./index-DuOv7Qep.js";export{o as default};
