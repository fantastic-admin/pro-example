import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-B69iPubo.js";import"./index.vue_vue_type_script_setup_true_lang-Cu8jkNvg.js";import"./index-De8Oh0HC.js";export{o as default};
