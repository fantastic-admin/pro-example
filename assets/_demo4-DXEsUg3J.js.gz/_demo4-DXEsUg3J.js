import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-Crac0zxJ.js";import"./index.vue_vue_type_script_setup_true_lang-DA2jPgcK.js";import"./index-CkQ8ZzMl.js";export{o as default};
