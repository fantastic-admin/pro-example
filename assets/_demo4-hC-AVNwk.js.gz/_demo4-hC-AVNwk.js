import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-CXCtWJNh.js";import"./index.vue_vue_type_script_setup_true_lang-DEglhcT3.js";import"./index-BLSV4yIg.js";export{o as default};
