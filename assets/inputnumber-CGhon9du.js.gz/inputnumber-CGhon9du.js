import{_ as m}from"./inputnumber.vue_vue_type_script_setup_true_lang-Bq8d_4nn.js";import"./index-B13-Jify.js";export{m as default};
