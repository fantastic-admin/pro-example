import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-D8VD4zQT.js";import"./index.vue_vue_type_script_setup_true_lang-DFG0o2No.js";import"./index-DRFMav3n.js";export{o as default};
