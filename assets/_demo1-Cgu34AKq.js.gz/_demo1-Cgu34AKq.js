import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-Bbeq3HVD.js";import"./index.vue_vue_type_script_setup_true_lang-Dqb1On_A.js";import"./index-DOTJNdHl.js";export{o as default};
