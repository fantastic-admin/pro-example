import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CJU-gzLw.js";import"./dictionary-okf8d7LM.js";import"./index-Db5JpCpC.js";export{o as default};
