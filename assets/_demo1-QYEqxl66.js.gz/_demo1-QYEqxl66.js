import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-D3lyCHUY.js";import"./index-CWNuUaIY.js";import"./index-DFNzsyWB.js";export{o as default};
