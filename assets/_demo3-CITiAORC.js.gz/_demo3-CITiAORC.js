import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-CwF-ee2F.js";import"./index.vue_vue_type_script_setup_true_lang-CMWHRSnr.js";import"./index-CkQ8ZzMl.js";export{o as default};
