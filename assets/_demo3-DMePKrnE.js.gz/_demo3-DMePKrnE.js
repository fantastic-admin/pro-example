import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-C13nRf_b.js";import"./index.vue_vue_type_script_setup_true_lang-C_Z9yUsF.js";import"./index-CngbNVLW.js";export{o as default};
