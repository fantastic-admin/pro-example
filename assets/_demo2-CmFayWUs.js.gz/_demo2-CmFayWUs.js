import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-FAEKgLHk.js";import"./index-DQdGVpLy.js";import"./index-C3QTkpZp.js";export{o as default};
