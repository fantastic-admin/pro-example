import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-De9UiOtU.js";import"./index-DFNzsyWB.js";import"./index-rcH5lx6K.js";export{o as default};
