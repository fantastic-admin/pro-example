import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-BZet1G74.js";import"./index-DcWv3uSk.js";import"./index-B13-Jify.js";export{o as default};
