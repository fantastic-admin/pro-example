import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-Dl_2pADP.js";import"./index-BHkWVPDT.js";import"./menu-Cr6Cbtqy.js";import"./role-C3490YPY.js";export{o as default};
