import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DubdnCNR.js";import"./dictionary-CpdP3JL6.js";import"./index-DL7SpVKF.js";export{o as default};
