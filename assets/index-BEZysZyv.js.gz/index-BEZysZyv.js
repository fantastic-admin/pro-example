import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-D6gkZbfS.js";import"./index-C1X-Si6V.js";import"./role-C-OR-g0T.js";export{o as default};
