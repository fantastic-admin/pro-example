import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-CnwQlPJc.js";import{d as t,f as c,g as r,h as a,a8 as d,j as m,l,V as n}from"./index-D4ShR5zg.js";import s from"./_demo1-DH8300bl.js";import"./index-Z-JH_SAD.js";import"./index.vue_vue_type_script_setup_true_lang-C1sgmnpp.js";const f=`<template>
  <div class="flex gap-8">
    <FaBadge :value="true">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge :value="99">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="噢">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="9" variant="secondary">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
    <FaBadge value="9" variant="destructive">
      <FaIcon name="i-ri:notification-3-line" />
    </FaBadge>
  </div>
</template>
`,p=t({__name:"index",setup(F){return(_,u)=>{const e=d,i=o;return r(),c("div",null,[a(e,{title:"徽章",description:"FaBadge"}),a(i,{code:l(f)},{default:m(()=>[a(s)]),_:1},8,["code"])])}}});typeof n=="function"&&n(p);export{p as default};
