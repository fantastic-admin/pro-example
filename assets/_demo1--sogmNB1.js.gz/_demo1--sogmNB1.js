import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-BjuWgfHe.js";import"./index-m00YXFvT.js";import"./index-CngbNVLW.js";export{o as default};
