import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-C6Cbu3Xz.js";import"./index.vue_vue_type_script_setup_true_lang-B2IBEkRN.js";import"./index-xj0hzzoN.js";export{o as default};
