import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CW2RyWbw.js";import"./index-9dZpJgz5.js";import"./index-H6KsPIiT.js";export{o as default};
