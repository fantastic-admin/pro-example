import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-XE8oBqqc.js";import"./index.vue_vue_type_script_setup_true_lang-Dls23fAH.js";import"./index-CngbNVLW.js";export{o as default};
