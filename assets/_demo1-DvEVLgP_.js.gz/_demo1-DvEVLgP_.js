import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CT6s2IW5.js";import"./index-CEv70T7X.js";import"./index-BFPO48W4.js";export{o as default};
