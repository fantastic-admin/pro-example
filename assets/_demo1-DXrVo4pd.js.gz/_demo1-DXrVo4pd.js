import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CY0qyNIr.js";import"./index-ok7mAVWN.js";import"./index-H6QnEWHf.js";export{o as default};
