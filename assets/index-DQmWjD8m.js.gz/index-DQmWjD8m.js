import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DiDPXbMJ.js";import"./dictionary-Ym2RcNnB.js";import"./index-CkXBA4BI.js";export{o as default};
