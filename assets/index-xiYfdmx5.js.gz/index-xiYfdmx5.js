import{_ as m}from"./index.vue_vue_type_script_setup_true_lang-BHLIpBvg.js";import"./index-xj0hzzoN.js";export{m as default};
