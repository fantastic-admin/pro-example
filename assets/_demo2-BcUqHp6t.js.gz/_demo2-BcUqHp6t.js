import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-DlDTJ0xB.js";import"./index.vue_vue_type_script_setup_true_lang-BsRaChHK.js";import"./index-CngbNVLW.js";export{o as default};
