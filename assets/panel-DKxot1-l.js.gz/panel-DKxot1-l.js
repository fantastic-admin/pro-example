import{_ as o}from"./panel.vue_vue_type_script_setup_true_lang-BRXLyjL0.js";import"./index-De8Oh0HC.js";import"./all.vue_vue_type_script_setup_true_lang-DKdnvKob.js";export{o as default};
