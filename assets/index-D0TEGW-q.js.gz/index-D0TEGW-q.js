import{_ as o}from"./index.vue_vue_type_script_setup_true_lang-DGGlUo_Q.js";import"./department-DTDd-vjC.js";import"./index-CkXBA4BI.js";export{o as default};
