import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DG8VFP45.js";import"./index.vue_vue_type_script_setup_true_lang-Bar9Goto.js";import"./index-DFNzsyWB.js";export{o as default};
