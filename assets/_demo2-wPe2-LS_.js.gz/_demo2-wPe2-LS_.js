import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-C3rCOJ6g.js";import"./index-28uxndRW.js";import"./index-DAKfMll4.js";export{o as default};
