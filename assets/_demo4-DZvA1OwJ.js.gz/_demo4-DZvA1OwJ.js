import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-DCFnry9W.js";import"./index.vue_vue_type_script_setup_true_lang-CF0empYk.js";import"./index-Cm5PYwOf.js";export{o as default};
