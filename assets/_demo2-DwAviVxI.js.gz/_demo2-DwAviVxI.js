import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-D-Ktzm0q.js";import"./index.vue_vue_type_script_setup_true_lang-C3hCv3bC.js";import"./index-BHkWVPDT.js";export{o as default};
