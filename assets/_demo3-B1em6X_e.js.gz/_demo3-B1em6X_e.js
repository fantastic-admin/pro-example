import{_ as o}from"./_demo3.vue_vue_type_script_setup_true_lang-2MZV3LjN.js";import"./index.vue_vue_type_script_setup_true_lang-Cxy3jqPZ.js";import"./index-CkXBA4BI.js";export{o as default};
