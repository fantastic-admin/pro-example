import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-DG3u7XU6.js";import"./index.vue_vue_type_script_setup_true_lang-SqDhYYOY.js";import"./index-CphCexG_.js";export{o as default};
