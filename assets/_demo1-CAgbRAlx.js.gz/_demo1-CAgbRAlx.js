import{_ as o}from"./_demo1.vue_vue_type_script_setup_true_lang-CzNT48UZ.js";import"./index-DU7ESt7E.js";import"./index-BLSV4yIg.js";export{o as default};
