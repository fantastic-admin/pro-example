import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-CCdy4a1P.js";import"./index-C2sVwYqs.js";import"./index-Bnionyve.js";export{o as default};
