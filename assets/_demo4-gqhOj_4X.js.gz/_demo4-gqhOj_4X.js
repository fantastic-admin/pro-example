import{_ as o}from"./_demo4.vue_vue_type_script_setup_true_lang-n92VnN_z.js";import"./index.vue_vue_type_script_setup_true_lang-BG3F60_p.js";import"./index-DOTJNdHl.js";export{o as default};
