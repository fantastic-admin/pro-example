import{_ as o}from"./_demo2.vue_vue_type_script_setup_true_lang-Bg5a-Qau.js";import"./index-DiZsMs-Z.js";import"./index-CphCexG_.js";export{o as default};
